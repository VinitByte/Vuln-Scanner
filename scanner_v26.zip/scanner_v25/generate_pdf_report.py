#!/usr/bin/env python3
"""
VulnOrchestrator — PDF Report Generator
Converts scan output files into a polished, non-technical PDF report.

Usage:
    python3 generate_pdf_report.py <output_dir> [--mode full|vuln] [--target example.com]

Example:
    python3 generate_pdf_report.py outputs/example.com --mode full --target example.com
"""

import os
import sys
import argparse
import re
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm, cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable, KeepTogether
)
from reportlab.platypus.flowables import Flowable
from reportlab.pdfgen import canvas as pdfcanvas

# ─── Color Palette ────────────────────────────────────────────────────────────
DARK_BG        = colors.HexColor("#0D1117")
BRAND_BLUE     = colors.HexColor("#1E88E5")
BRAND_BLUE_LT  = colors.HexColor("#E3F2FD")
ACCENT_TEAL    = colors.HexColor("#00ACC1")
ACCENT_TEAL_LT = colors.HexColor("#E0F7FA")
DANGER_RED     = colors.HexColor("#E53935")
DANGER_RED_LT  = colors.HexColor("#FFEBEE")
WARN_ORANGE    = colors.HexColor("#FB8C00")
WARN_ORANGE_LT = colors.HexColor("#FFF3E0")
OK_GREEN       = colors.HexColor("#43A047")
OK_GREEN_LT    = colors.HexColor("#E8F5E9")
GREY_DARK      = colors.HexColor("#37474F")
GREY_MID       = colors.HexColor("#78909C")
GREY_LIGHT     = colors.HexColor("#ECEFF1")
GREY_BORDER    = colors.HexColor("#CFD8DC")
WHITE          = colors.white
BLACK          = colors.HexColor("#1A1A2E")

# ─── Severity keyword maps ─────────────────────────────────────────────────────
SEVERITY_CRITICAL_KW = ["critical", "[critical]", "rce", "remote code", "sql injection", "sqli"]
SEVERITY_HIGH_KW     = ["high", "[high]", "xss", "cross-site", "open redirect", "lfi", "rfi",
                         "command injection", "idor", "ssrf"]
SEVERITY_MEDIUM_KW   = ["medium", "[medium]", "cors", "misconfiguration", "exposure", "disclosure",
                         "takeover", "subdomain takeover"]
SEVERITY_LOW_KW      = ["low", "[low]", "info", "[info]", "banner", "cookie", "ssl", "tls",
                         "redirect", "header"]

SECTION_META = {
    "Live Subdomains":                ("🌐", BRAND_BLUE,   BRAND_BLUE_LT,
        "Subdomains that are live and reachable on the internet."),
    "Technology Detection":           ("🔍", ACCENT_TEAL,  ACCENT_TEAL_LT,
        "Technologies, frameworks and server software detected on the target."),
    "Open Ports":                     ("🔌", GREY_DARK,    GREY_LIGHT,
        "Network ports that are open and accepting connections."),
    "Subdomain Takeover":             ("⚠️", WARN_ORANGE,  WARN_ORANGE_LT,
        "Subdomains that may be vulnerable to takeover by an attacker."),
    "Filtered URLs":                  ("🔗", GREY_DARK,    GREY_LIGHT,
        "URLs collected from the target during crawling."),
    "JS Files":                       ("📜", GREY_DARK,    GREY_LIGHT,
        "JavaScript files found on the target."),
    "SecretFinder — JS Secrets":      ("🔑", DANGER_RED,   DANGER_RED_LT,
        "Potential secrets, API keys or tokens found inside JavaScript files."),
    "Gitleaks — Secret Scan":         ("🔓", DANGER_RED,   DANGER_RED_LT,
        "Sensitive data leaks detected via Gitleaks analysis."),
    "Parameters Discovered":          ("🧩", GREY_DARK,    GREY_LIGHT,
        "URL parameters discovered — each is a potential attack surface."),
    "Final Parameter URLs":           ("🎯", GREY_DARK,    GREY_LIGHT,
        "Final list of parameterised URLs used for vulnerability testing."),
    "Nuclei Results":                 ("🧬", DANGER_RED,   DANGER_RED_LT,
        "Vulnerabilities detected by the Nuclei scanner."),
    "Dalfox — XSS Results":           ("💉", DANGER_RED,   DANGER_RED_LT,
        "Cross-Site Scripting (XSS) vulnerabilities found by Dalfox."),
    "SQLMap Results":                 ("🗄️", DANGER_RED,   DANGER_RED_LT,
        "SQL Injection vulnerabilities found by SQLMap."),
    "Wapiti Results":                 ("🕷️", WARN_ORANGE,  WARN_ORANGE_LT,
        "Web vulnerabilities detected by the Wapiti scanner."),
    "Nikto Results":                  ("🔎", WARN_ORANGE,  WARN_ORANGE_LT,
        "Web server misconfigurations and known issues found by Nikto."),
    "CORScanner Results":             ("🌍", WARN_ORANGE,  WARN_ORANGE_LT,
        "Cross-Origin Resource Sharing (CORS) policy issues detected."),
    "WAF Detection":                  ("🛡️", OK_GREEN,     OK_GREEN_LT,
        "Web Application Firewall detection results."),
}

# ─── Custom Flowables ─────────────────────────────────────────────────────────

class ColoredLine(Flowable):
    """A full-width colored horizontal rule."""
    def __init__(self, color, thickness=1.5, width=None):
        super().__init__()
        self.line_color = color
        self.thickness  = thickness
        self._width     = width

    def wrap(self, avail_w, avail_h):
        self.avail_w = avail_w
        return (avail_w, self.thickness + 2)

    def draw(self):
        self.canv.setStrokeColor(self.line_color)
        self.canv.setLineWidth(self.thickness)
        w = self._width or self.avail_w
        self.canv.line(0, self.thickness / 2, w, self.thickness / 2)


class RoundedBox(Flowable):
    """A rounded-corner colored box drawn behind content."""
    def __init__(self, fill_color, border_color, width, height, radius=6):
        super().__init__()
        self.fill_color   = fill_color
        self.border_color = border_color
        self._w           = width
        self._h           = height
        self.radius       = radius

    def wrap(self, aw, ah):
        return (self._w, self._h)

    def draw(self):
        c = self.canv
        c.setFillColor(self.fill_color)
        c.setStrokeColor(self.border_color)
        c.setLineWidth(0.5)
        c.roundRect(0, 0, self._w, self._h, self.radius, stroke=1, fill=1)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def read_file(path, max_bytes=400_000):
    try:
        with open(path, "r", errors="replace") as f:
            return f.read(max_bytes)
    except Exception:
        return ""


def classify_severity(text):
    """Return (label, color, bg_color) for a line of scan output."""
    t = text.lower()
    for kw in SEVERITY_CRITICAL_KW:
        if kw in t:
            return "CRITICAL", DANGER_RED, DANGER_RED_LT
    for kw in SEVERITY_HIGH_KW:
        if kw in t:
            return "HIGH", WARN_ORANGE, WARN_ORANGE_LT
    for kw in SEVERITY_MEDIUM_KW:
        if kw in t:
            return "MEDIUM", BRAND_BLUE, BRAND_BLUE_LT
    for kw in SEVERITY_LOW_KW:
        if kw in t:
            return "LOW", OK_GREEN, OK_GREEN_LT
    return None, None, None


def count_lines(text):
    return len([l for l in text.splitlines() if l.strip()])


def summarise_section(title, content):
    """Generate a plain-English 1-liner summary for non-technical readers."""
    n = count_lines(content)
    summaries = {
        "Live Subdomains":
            f"{n} live subdomain(s) found — each is a separate entry point into the target.",
        "Technology Detection":
            f"Technology stack identified across {n} host(s).",
        "Open Ports":
            f"{n} open port(s) detected — open ports can expose services to the internet.",
        "Subdomain Takeover":
            f"{n} potential subdomain takeover target(s) found.",
        "Filtered URLs":
            f"{n} URL(s) discovered during crawling.",
        "JS Files":
            f"{n} JavaScript file(s) found and analysed.",
        "SecretFinder — JS Secrets":
            (f"⚠️  {n} potential secret(s) / API key(s) leaked in JavaScript files — review urgently."
             if n else "No secrets detected in JavaScript files."),
        "Gitleaks — Secret Scan":
            (f"⚠️  {n} secret leak(s) detected — credentials may be exposed."
             if n else "No secret leaks detected."),
        "Parameters Discovered":
            f"{n} URL parameter(s) identified as potential attack surface.",
        "Final Parameter URLs":
            f"{n} parameter URL(s) used during vulnerability testing.",
        "Nuclei Results":
            (f"🚨 {n} vulnerability/vulnerabilities detected by Nuclei — review each finding."
             if n else "Nuclei found no issues."),
        "Dalfox — XSS Results":
            (f"🚨 {n} XSS (Cross-Site Scripting) issue(s) found." if n else "No XSS issues found."),
        "SQLMap Results":
            (f"🚨 {n} SQL Injection issue(s) detected." if n else "No SQL Injection issues found."),
        "Wapiti Results":
            f"{n} web vulnerability finding(s) from Wapiti.",
        "Nikto Results":
            f"{n} server/configuration issue(s) from Nikto.",
        "CORScanner Results":
            (f"⚠️  {n} CORS misconfiguration(s) found." if n else "No CORS issues detected."),
        "WAF Detection":
            ("A Web Application Firewall is active — some attacks may be blocked."
             if n else "No WAF detected."),
    }
    for key in summaries:
        if key.lower() in title.lower():
            return summaries[key]
    return f"{n} line(s) of output."


def make_styles():
    base = getSampleStyleSheet()

    styles = {
        "cover_title": ParagraphStyle(
            "cover_title", fontName="Helvetica-Bold",
            fontSize=32, textColor=WHITE, leading=40, alignment=TA_CENTER
        ),
        "cover_subtitle": ParagraphStyle(
            "cover_subtitle", fontName="Helvetica",
            fontSize=14, textColor=colors.HexColor("#90CAF9"),
            leading=20, alignment=TA_CENTER
        ),
        "cover_meta": ParagraphStyle(
            "cover_meta", fontName="Helvetica",
            fontSize=11, textColor=colors.HexColor("#B0BEC5"),
            leading=16, alignment=TA_CENTER
        ),
        "toc_heading": ParagraphStyle(
            "toc_heading", fontName="Helvetica-Bold",
            fontSize=18, textColor=DARK_BG, leading=24, spaceAfter=12
        ),
        "toc_item": ParagraphStyle(
            "toc_item", fontName="Helvetica",
            fontSize=11, textColor=GREY_DARK, leading=18, leftIndent=12
        ),
        "section_heading": ParagraphStyle(
            "section_heading", fontName="Helvetica-Bold",
            fontSize=14, textColor=WHITE, leading=20
        ),
        "section_desc": ParagraphStyle(
            "section_desc", fontName="Helvetica-Oblique",
            fontSize=9.5, textColor=GREY_MID, leading=14, spaceAfter=6
        ),
        "summary_box": ParagraphStyle(
            "summary_box", fontName="Helvetica",
            fontSize=10, textColor=GREY_DARK, leading=15, spaceAfter=4
        ),
        "body_mono": ParagraphStyle(
            "body_mono", fontName="Courier",
            fontSize=7.5, textColor=colors.HexColor("#263238"),
            leading=11, leftIndent=0, wordWrap='CJK'
        ),
        "severity_tag": ParagraphStyle(
            "severity_tag", fontName="Helvetica-Bold",
            fontSize=7.5, textColor=WHITE, leading=10
        ),
        "findings_line": ParagraphStyle(
            "findings_line", fontName="Courier",
            fontSize=8, textColor=BLACK, leading=12, wordWrap='CJK'
        ),
        "page_header": ParagraphStyle(
            "page_header", fontName="Helvetica",
            fontSize=8, textColor=GREY_MID, leading=10
        ),
        "empty_msg": ParagraphStyle(
            "empty_msg", fontName="Helvetica-Oblique",
            fontSize=10, textColor=GREY_MID, leading=14, alignment=TA_CENTER
        ),
        "exec_heading": ParagraphStyle(
            "exec_heading", fontName="Helvetica-Bold",
            fontSize=16, textColor=DARK_BG, leading=22, spaceAfter=8
        ),
        "exec_body": ParagraphStyle(
            "exec_body", fontName="Helvetica",
            fontSize=10.5, textColor=GREY_DARK, leading=16, spaceAfter=6,
            alignment=TA_JUSTIFY
        ),
        "stat_number": ParagraphStyle(
            "stat_number", fontName="Helvetica-Bold",
            fontSize=28, textColor=BRAND_BLUE, leading=34, alignment=TA_CENTER
        ),
        "stat_label": ParagraphStyle(
            "stat_label", fontName="Helvetica",
            fontSize=9, textColor=GREY_MID, leading=12, alignment=TA_CENTER
        ),
    }
    return styles


# ─── Page Template (header/footer) ───────────────────────────────────────────

class ReportCanvas(pdfcanvas.Canvas):
    def __init__(self, *args, **kwargs):
        self.target   = kwargs.pop("target", "Unknown")
        self.gen_time = kwargs.pop("gen_time", "")
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_page_chrome(num_pages)
            super().showPage()
        super().save()

    def _draw_page_chrome(self, total):
        page_num = self._pageNumber
        w, h = A4

        # Header bar
        self.setFillColor(DARK_BG)
        self.rect(0, h - 26*mm, w, 26*mm, fill=1, stroke=0)
        self.setFillColor(BRAND_BLUE)
        self.rect(0, h - 26*mm, 4, 26*mm, fill=1, stroke=0)  # accent strip

        self.setFont("Helvetica-Bold", 9)
        self.setFillColor(WHITE)
        self.drawString(14*mm, h - 14*mm, "VulnOrchestrator — Security Assessment Report")
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#90CAF9"))
        self.drawRightString(w - 14*mm, h - 14*mm, f"Target: {self.target}")

        # Footer bar
        self.setFillColor(GREY_LIGHT)
        self.rect(0, 0, w, 16*mm, fill=1, stroke=0)
        self.setStrokeColor(GREY_BORDER)
        self.setLineWidth(0.5)
        self.line(0, 16*mm, w, 16*mm)

        self.setFont("Helvetica", 7.5)
        self.setFillColor(GREY_MID)
        self.drawString(14*mm, 8*mm, f"Generated: {self.gen_time}  |  CONFIDENTIAL — For authorised use only")
        self.drawRightString(w - 14*mm, 8*mm, f"Page {page_num} of {total}")


# ─── Cover Page ───────────────────────────────────────────────────────────────

def build_cover(story, styles, target, mode_label, now):
    w, h = A4

    # Full dark background block — simulate with a tall table
    cover_data = [[""]]
    cover_table = Table(cover_data, colWidths=[w - 40*mm], rowHeights=[120*mm])
    cover_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), DARK_BG),
        ("ROUNDEDCORNERS", [8]),
        ("TOPPADDING", (0, 0), (-1, -1), 40*mm),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 40*mm),
    ]))

    story.append(Spacer(1, 20*mm))

    # Logo / brand row
    brand_data = [
        [Paragraph('<font color="#1E88E5" size="38">&#x1F512;</font>', ParagraphStyle(
            "ico", fontName="Helvetica-Bold", fontSize=38, alignment=TA_CENTER))]
    ]
    brand_table = Table(brand_data, colWidths=[w - 40*mm])
    brand_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), DARK_BG),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 10*mm),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4*mm),
        ("ROUNDEDCORNERS", [8]),
    ]))

    # Assemble cover block
    cover_inner = [
        [Paragraph("Security Assessment Report", styles["cover_title"])],
        [Spacer(1, 3*mm)],
        [Paragraph("VulnOrchestrator", styles["cover_subtitle"])],
        [Spacer(1, 8*mm)],
        [ColoredLine(BRAND_BLUE, thickness=1, width=80*mm)],
        [Spacer(1, 8*mm)],
        [Paragraph(f"Target:  <b>{target}</b>", styles["cover_meta"])],
        [Paragraph(f"Scan Mode:  {mode_label}", styles["cover_meta"])],
        [Paragraph(f"Date:  {now}", styles["cover_meta"])],
        [Spacer(1, 12*mm)],
        [Paragraph("CONFIDENTIAL", ParagraphStyle(
            "conf", fontName="Helvetica-Bold", fontSize=9,
            textColor=colors.HexColor("#EF5350"), alignment=TA_CENTER, letterSpacing=4))],
    ]
    cover_tbl = Table(cover_inner, colWidths=[w - 40*mm])
    cover_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), DARK_BG),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ("ROUNDEDCORNERS", [10]),
        ("LEFTPADDING", (0, 0), (-1, -1), 20*mm),
        ("RIGHTPADDING", (0, 0), (-1, -1), 20*mm),
    ]))
    story.append(cover_tbl)
    story.append(PageBreak())


# ─── Executive Summary ────────────────────────────────────────────────────────

def build_exec_summary(story, styles, target, mode, sections_data):
    story.append(Spacer(1, 8*mm))
    story.append(Paragraph("Executive Summary", styles["exec_heading"]))
    story.append(ColoredLine(BRAND_BLUE, thickness=2))
    story.append(Spacer(1, 5*mm))

    story.append(Paragraph(
        f"This report presents the findings of an automated security scan conducted against "
        f"<b>{target}</b>. The scan was performed using VulnOrchestrator in <b>{mode}</b> mode. "
        f"All findings are generated by automated tools and should be reviewed and validated "
        f"by a security professional before taking action.",
        styles["exec_body"]
    ))
    story.append(Spacer(1, 5*mm))
    story.append(Paragraph(
        "The sections below contain both technical details and plain-English explanations "
        "to help non-technical stakeholders understand the scope and impact of each finding.",
        styles["exec_body"]
    ))
    story.append(Spacer(1, 8*mm))

    # Build stat cards
    vuln_sections = ["Nuclei Results", "Dalfox — XSS Results", "SQLMap Results",
                     "Wapiti Results", "Nikto Results"]
    total_vulns   = sum(count_lines(c) for t, c in sections_data if
                        any(v.lower() in t.lower() for v in vuln_sections) and c.strip())
    live_subs     = next((count_lines(c) for t, c in sections_data
                          if "live subdomain" in t.lower() and c.strip()), 0)
    open_ports    = next((count_lines(c) for t, c in sections_data
                          if "open port" in t.lower() and c.strip()), 0)
    secrets_found = next((count_lines(c) for t, c in sections_data
                          if "secret" in t.lower() and c.strip()), 0)

    stat_data = [[
        Paragraph(str(live_subs),     styles["stat_number"]),
        Paragraph(str(open_ports),    styles["stat_number"]),
        Paragraph(str(total_vulns),   styles["stat_number"]),
        Paragraph(str(secrets_found), styles["stat_number"]),
    ], [
        Paragraph("Live Subdomains",  styles["stat_label"]),
        Paragraph("Open Ports",       styles["stat_label"]),
        Paragraph("Vulnerabilities",  styles["stat_label"]),
        Paragraph("Secrets Found",    styles["stat_label"]),
    ]]

    cw = (A4[0] - 40*mm) / 4
    stat_table = Table(stat_data, colWidths=[cw]*4, rowHeights=[18*mm, 10*mm])
    stat_table.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), GREY_LIGHT),
        ("ALIGN",         (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING",    (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("GRID",          (0, 0), (-1, -1), 0.5, GREY_BORDER),
        ("ROUNDEDCORNERS", [6]),
        # Colour the vuln count red if > 0
        ("TEXTCOLOR", (2, 0), (2, 0), DANGER_RED if total_vulns > 0 else OK_GREEN),
        ("TEXTCOLOR", (3, 0), (3, 0), DANGER_RED if secrets_found > 0 else OK_GREEN),
    ]))
    story.append(stat_table)
    story.append(Spacer(1, 8*mm))

    # Severity legend
    legend_items = [
        ("CRITICAL", DANGER_RED),
        ("HIGH",     WARN_ORANGE),
        ("MEDIUM",   BRAND_BLUE),
        ("LOW / INFO", OK_GREEN),
    ]
    legend_data = [[
        Table([[Paragraph(lbl, ParagraphStyle("ll", fontName="Helvetica-Bold",
                           fontSize=8, textColor=WHITE, alignment=TA_CENTER))]],
              colWidths=[28*mm], rowHeights=[7*mm],
              style=TableStyle([("BACKGROUND", (0,0), (-1,-1), col),
                                ("ALIGN", (0,0), (-1,-1), "CENTER"),
                                ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
                                ("ROUNDEDCORNERS", [4])]))
        for lbl, col in legend_items
    ]]
    leg_table = Table(legend_data, colWidths=[(A4[0]-40*mm)/4]*4)
    leg_table.setStyle(TableStyle([("ALIGN", (0,0), (-1,-1), "CENTER"),
                                   ("VALIGN", (0,0), (-1,-1), "MIDDLE")]))
    story.append(Paragraph("Severity Legend", styles["section_desc"]))
    story.append(leg_table)
    story.append(PageBreak())


# ─── Table of Contents ────────────────────────────────────────────────────────

def build_toc(story, styles, sections_data):
    story.append(Spacer(1, 8*mm))
    story.append(Paragraph("Table of Contents", styles["toc_heading"]))
    story.append(ColoredLine(BRAND_BLUE, thickness=2))
    story.append(Spacer(1, 4*mm))

    toc_rows = [["#", "Section", "Findings"]]
    for i, (title, content) in enumerate(sections_data, 1):
        meta = SECTION_META.get(title, ("", GREY_MID, GREY_LIGHT, ""))
        n    = count_lines(content) if content.strip() else 0
        toc_rows.append([str(i), title, str(n) if n else "—"])

    cw = A4[0] - 40*mm
    toc_tbl = Table(toc_rows, colWidths=[10*mm, cw - 30*mm, 20*mm])
    toc_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0), DARK_BG),
        ("TEXTCOLOR",     (0, 0), (-1, 0), WHITE),
        ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0), 9),
        ("ALIGN",         (0, 0), (-1, -1), "LEFT"),
        ("ALIGN",         (2, 0), (2, -1), "CENTER"),
        ("FONTNAME",      (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 1), (-1, -1), 9.5),
        ("TEXTCOLOR",     (0, 1), (-1, -1), GREY_DARK),
        ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, GREY_LIGHT]),
        ("GRID",          (0, 0), (-1, -1), 0.4, GREY_BORDER),
        ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING",   (0, 0), (-1, -1), 8),
        ("ROUNDEDCORNERS", [4]),
    ]))
    story.append(toc_tbl)
    story.append(PageBreak())


# ─── Section Builder ──────────────────────────────────────────────────────────

def build_section(story, styles, index, title, content):
    meta      = SECTION_META.get(title, ("", GREY_DARK, GREY_LIGHT, ""))
    icon, hdr_color, bg_color, desc = meta[0], meta[1], meta[2], meta[3]

    display_title = f"{icon}  {title}" if icon else title
    has_content   = bool(content and content.strip())
    summary       = summarise_section(title, content) if has_content else "No data collected for this section."

    # Section header bar
    hdr_data = [[Paragraph(f"{index}. {display_title}", styles["section_heading"])]]
    hdr_table = Table(hdr_data, colWidths=[A4[0] - 40*mm])
    hdr_table.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), hdr_color),
        ("TOPPADDING",    (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ("ROUNDEDCORNERS", [6]),
    ]))

    story.append(KeepTogether([
        Spacer(1, 6*mm),
        hdr_table,
    ]))

    # Description
    if desc:
        story.append(Spacer(1, 2*mm))
        story.append(Paragraph(desc, styles["section_desc"]))

    # Summary pill
    summary_data = [[Paragraph(f"<b>Summary:</b>  {summary}", styles["summary_box"])]]
    summary_table = Table(summary_data, colWidths=[A4[0] - 40*mm])
    summary_table.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), bg_color),
        ("TOPPADDING",    (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
        ("ROUNDEDCORNERS", [4]),
        ("BOX",           (0, 0), (-1, -1), 0.5, hdr_color),
    ]))
    story.append(Spacer(1, 2*mm))
    story.append(summary_table)

    # Content
    story.append(Spacer(1, 3*mm))
    if not has_content:
        emp_data = [[Paragraph("No output collected — tool may not have run or produced no results.",
                               styles["empty_msg"])]]
        emp_table = Table(emp_data, colWidths=[A4[0] - 40*mm])
        emp_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), GREY_LIGHT),
            ("TOPPADDING", (0, 0), (-1, -1), 10),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
            ("ROUNDEDCORNERS", [4]),
        ]))
        story.append(emp_table)
    else:
        lines = content.splitlines()
        # Cap at 500 lines for readability
        truncated = len(lines) > 500
        display_lines = lines[:500] if truncated else lines

        rows = []
        for line in display_lines:
            if not line.strip():
                continue
            sev_label, sev_color, sev_bg = classify_severity(line)
            safe_line = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            if sev_label:
                tag = Table(
                    [[Paragraph(sev_label, styles["severity_tag"])]],
                    colWidths=[18*mm], rowHeights=[5*mm],
                    style=TableStyle([
                        ("BACKGROUND", (0,0), (-1,-1), sev_color),
                        ("ALIGN", (0,0), (-1,-1), "CENTER"),
                        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
                        ("TOPPADDING", (0,0), (-1,-1), 1),
                        ("BOTTOMPADDING", (0,0), (-1,-1), 1),
                        ("ROUNDEDCORNERS", [3]),
                    ])
                )
                rows.append([tag, Paragraph(safe_line, styles["findings_line"])])
            else:
                rows.append(["", Paragraph(safe_line, styles["body_mono"])])

        if rows:
            cw = A4[0] - 40*mm
            content_tbl = Table(rows, colWidths=[20*mm, cw - 20*mm])
            content_tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, -1), colors.HexColor("#F5F7FA")),
                ("ROWBACKGROUNDS",(0, 0), (-1, -1),
                 [colors.HexColor("#F5F7FA"), colors.HexColor("#ECEFF1")]),
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING",    (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING",   (0, 0), (-1, -1), 6),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
                ("GRID",          (0, 0), (-1, -1), 0.3, GREY_BORDER),
                ("ROUNDEDCORNERS", [4]),
            ]))
            story.append(content_tbl)

        if truncated:
            story.append(Spacer(1, 2*mm))
            story.append(Paragraph(
                f"<i>... output truncated — showing first 500 of {len(lines)} lines. "
                f"See the raw .txt file for full output.</i>",
                styles["section_desc"]
            ))

    story.append(Spacer(1, 4*mm))


# ─── Main ─────────────────────────────────────────────────────────────────────

FULL_SECTIONS = [
    ("Live Subdomains",                "live.txt"),
    ("Technology Detection",           "whatweb.txt"),
    ("Open Ports",                     "nmap.txt"),
    ("Subdomain Takeover",             "takeover.txt"),
    ("Filtered URLs",                  "filtered_urls.txt"),
    ("JS Files",                       "jsfiles.txt"),
    ("SecretFinder — JS Secrets",      "js_secrets.txt"),
    ("Gitleaks — Secret Scan",         "gitleaks.txt"),
    ("Parameters Discovered",          "total_params.txt"),
    ("Final Parameter URLs",           "final_paramurls.txt"),
]

VULN_SECTIONS = [
    ("Nuclei Results",       "nuclei.txt"),
    ("Dalfox — XSS Results", "dalfox.txt"),
    ("SQLMap Results",       "sqlmap.txt"),
    ("Wapiti Results",       "wapiti.txt"),
    ("Nikto Results",        "nikto.txt"),
    ("CORScanner Results",   "cors.txt"),
    ("WAF Detection",        "waf.txt"),
]


def generate_report(outdir, mode="full", target=None, output_path=None):
    target   = target or os.path.basename(outdir)
    now      = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    out_path = output_path or os.path.join(outdir, f"report_{os.path.basename(outdir)}.pdf")

    mode_label = "Full Scan" if mode == "full" else "Vulnerability-Only Scan"

    # Collect section data
    section_defs = (FULL_SECTIONS if mode == "full" else []) + VULN_SECTIONS
    sections_data = []
    for title, fname in section_defs:
        content = read_file(os.path.join(outdir, fname))
        sections_data.append((title, content))

    # Build PDF
    doc = SimpleDocTemplate(
        out_path,
        pagesize=A4,
        leftMargin=20*mm, rightMargin=20*mm,
        topMargin=30*mm, bottomMargin=22*mm,
        title=f"Security Report — {target}",
        author="VulnOrchestrator",
        subject="Automated Security Assessment",
    )

    styles = make_styles()
    story  = []

    build_cover(story, styles, target, mode_label, now)
    build_exec_summary(story, styles, target, mode_label, sections_data)
    build_toc(story, styles, sections_data)

    for i, (title, content) in enumerate(sections_data, 1):
        build_section(story, styles, i, title, content)

    # Disclaimer page
    story.append(PageBreak())
    story.append(Spacer(1, 10*mm))
    story.append(Paragraph("Disclaimer", styles["exec_heading"]))
    story.append(ColoredLine(BRAND_BLUE, thickness=2))
    story.append(Spacer(1, 5*mm))
    for line in [
        "This report has been generated by <b>VulnOrchestrator</b>, an automated security scanning "
        "platform. The findings in this report are produced by automated tools and may include "
        "false positives.",
        "All findings should be reviewed and validated by a qualified security professional before "
        "any remediation action is taken.",
        "This report is <b>CONFIDENTIAL</b> and intended solely for the organisation that authorised "
        "the security assessment. Unauthorised disclosure is prohibited.",
        "The scan was performed with authorisation. Scanning systems without explicit permission is "
        "illegal and unethical.",
    ]:
        story.append(Paragraph(line, styles["exec_body"]))
        story.append(Spacer(1, 3*mm))

    def make_canvas(*args, **kwargs):
        kwargs["target"]   = target
        kwargs["gen_time"] = now
        return ReportCanvas(*args, **kwargs)

    doc.build(story, canvasmaker=make_canvas)
    print(f"[+] PDF report saved: {out_path}")
    return out_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="VulnOrchestrator — Generate a polished PDF security report from scan output files."
    )
    parser.add_argument("outdir",           help="Path to the scan output directory (e.g. outputs/example.com)")
    parser.add_argument("--mode",           default="full", choices=["full", "vuln"],
                        help="Scan mode: 'full' or 'vuln' (default: full)")
    parser.add_argument("--target",         default=None,
                        help="Target domain/name shown on the report cover (default: output dir name)")
    parser.add_argument("--output",         default=None,
                        help="Output PDF path (default: <outdir>/report_<name>.pdf)")
    args = parser.parse_args()

    if not os.path.isdir(args.outdir):
        print(f"[!] Error: output directory not found: {args.outdir}")
        sys.exit(1)

    generate_report(args.outdir, mode=args.mode, target=args.target, output_path=args.output)
