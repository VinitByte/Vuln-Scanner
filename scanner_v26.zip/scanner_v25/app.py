from flask import Flask, render_template, request, jsonify, Response, send_file
import subprocess, os, threading, time, re, signal, shutil
from datetime import datetime
from generate_pdf_report import generate_report as _generate_pdf

app = Flask(__name__)

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
SCRIPTS_DIR = os.path.join(BASE_DIR, "scripts")
os.makedirs(OUTPUTS_DIR, exist_ok=True)

# ── State ─────────────────────────────────────────────────────────────────────
scan_status = {}
scan_logs   = {}
scan_procs  = {}
scan_stop   = {}

# ── Helpers ───────────────────────────────────────────────────────────────────

def sanitize_domain(target):
    domain = re.sub(r'^https?://', '', target).strip().rstrip('/')
    domain = domain.split('/')[0]
    return re.sub(r'[^a-zA-Z0-9._\-]', '_', domain)

def ts():
    return datetime.now().strftime('%H:%M:%S')

def _read_file(path, max_bytes=500_000):
    try:
        with open(path, "r", errors="replace") as f:
            return f.read(max_bytes)
    except Exception:
        return ""

def _section(title, icon, content, empty_msg="No data found."):
    content = content.strip() if content else ""
    body    = f"<pre>{content}</pre>" if content else f'<p class="empty">{empty_msg}</p>'
    return f'<div class="section"><h2>{icon} {title}</h2>{body}</div>'

# ── Subtool label map ─────────────────────────────────────────────────────────

SUBTOOL_LABELS = {
    "[subfinder]":       "Subfinder — Subdomain Enum",
    "[httpx]":           "httpx — Live Detection",
    "[whatweb]":         "WhatWeb — Tech Detection",
    "[nmap]":            "Nmap — Port Scan",
    "[subjack]":         "Subjack — Takeover Check",
    "[gau]":             "GAU — Historical URLs",
    "[katana]":          "Katana — Crawling",
    "[katana-js]":       "Katana JS Mode",
    "[url-collection]":  "URL Collection",
    "[uro]":             "URO — URL Dedup",
    "[unfurl]":          "Unfurl — Path/Param Extract",
    "[url-filter]":      "URL Filter",
    "[js-extraction]":   "JS Extraction",
    "[paramspider]":     "ParamSpider — Param Discovery",
    "[arjun]":           "Arjun — Param Discovery",
    "[param-discovery]": "Param Discovery",
    "[paramurls]":       "Building final_paramurls.txt",
    "[pipeline1]":       "Pipeline 1 — URLs with Params",
    "[pipeline2]":       "Pipeline 2 — Dir + Param Fuzz",
    "[value-fuzz]":      "ffuf — Value Fuzzing",
    "[gf]":              "GF — Pattern Filter",
    "[ffuf]":            "ffuf — Fuzzing",
    "[nuclei]":          "Nuclei — Template Scan",
    "[dalfox]":          "Dalfox — XSS Scan",
    "[sqlmap]":          "SQLMap — SQL Injection",
    "[vuln-scan]":       "Vuln Scanning",
    "[nikto]":           "Nikto — Server Audit",
    "[cors]":            "CORScanner — CORS Check",
    "[wapiti]":          "Wapiti — Web Vuln Scan",
    "[wafw00f]":         "wafw00f — WAF Detection",
}

# ── Pipeline runner ───────────────────────────────────────────────────────────

def run_stage(scan_id, label, script_path, args, outdir):
    stop_event = scan_stop.get(scan_id)
    if stop_event and stop_event.is_set():
        return False

    scan_status[scan_id]["current"] = label
    scan_logs[scan_id].append(f"[{ts()}] ▶ {label}")

    try:
        proc = subprocess.Popen(
            ["bash", script_path] + args,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, preexec_fn=os.setsid
        )
        scan_procs[scan_id] = proc

        for line in proc.stdout:
            if stop_event and stop_event.is_set():
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except Exception:
                    pass
                proc.wait()
                scan_logs[scan_id].append(f"[!] {label} interrupted")
                return False
            stripped = line.rstrip()
            scan_logs[scan_id].append(f"  {stripped}")
            for tag, sublabel in SUBTOOL_LABELS.items():
                if stripped.startswith(tag):
                    scan_status[scan_id]["current"] = sublabel
                    break

        proc.wait()
        scan_procs.pop(scan_id, None)

        if stop_event and stop_event.is_set():
            return False

        scan_logs[scan_id].append(f"[{ts()}] ✓ {label} done")
        return True

    except Exception as e:
        scan_logs[scan_id].append(f"[!] {label} error: {e}")
        return False


def _run_pipeline(scan_id, target, outdir, stages):
    total      = len(stages)
    stop_event = scan_stop.get(scan_id)
    for i, (script_name, label) in enumerate(stages):
        if stop_event and stop_event.is_set():
            break
        script_path = os.path.join(SCRIPTS_DIR, f"{script_name}.sh")
        run_stage(scan_id, label, script_path, [target, outdir], outdir)
        scan_status[scan_id]["progress"] = int(((i + 1) / total) * 100)

    if stop_event and stop_event.is_set():
        scan_status[scan_id].update({"status": "stopped", "current": "Stopped by user"})
        scan_logs[scan_id].append(f"[{ts()}] ⏹ Stopped. Partial results saved.")
    else:
        scan_status[scan_id].update({"status": "done", "current": "Complete"})
        scan_logs[scan_id].append(f"[{ts()}] ✅ Pipeline complete!")
    scan_stop.pop(scan_id, None)


def full_pipeline(scan_id, target):
    domain_folder = f"{sanitize_domain(target)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    outdir        = os.path.join(OUTPUTS_DIR, domain_folder)
    os.makedirs(outdir, exist_ok=True)

    scan_status[scan_id] = {"status": "running", "current": "Initializing...", "progress": 0, "outdir": domain_folder}
    scan_logs[scan_id]   = [
        f"[{ts()}] Pipeline started for: {target}",
        f"[{ts()}] Output: outputs/{domain_folder}/",
    ]

    stages = [
        ("01_subfinder",      "Subdomain Enumeration (subfinder)"),
        ("02_httpx",          "Live Host Detection (httpx)"),
        ("03_whatweb",        "Tech Detection (whatweb)"),
        ("04_nmap",           "Port Scanning (nmap)"),
        ("05_subjack",        "Subdomain Takeover (subjack)"),
        ("06_url_collection", "URL Collection (gau + katana)"),
        ("07_url_filter",     "URL Filtering (uro + unfurl)"),
        ("09_js_extraction",  "JS Analysis (katana-jc + linkfinder + secretfinder + gitleaks)"),
        ("10_param_discovery","Parameter Discovery (paramspider + arjun)"),
        ("11_paramurls",      "Build final_paramurls.txt + GF Patterns (ffuf + gf)"),
        ("12_nuclei",         "Nuclei — Template Scanning"),
        ("13_dalfox_sqlmap",  "XSS + SQLi (dalfox + sqlmap)"),
        ("14_nikto",          "Server Audit (nikto)"),
        ("15_cors",           "CORS Misconfiguration (corscanner)"),
        ("16_wapiti",         "Web Vuln Scan (wapiti)"),
        ("19_waf",            "WAF Detection (wafw00f)"),
    ]
    _run_pipeline(scan_id, target, outdir, stages)


def vuln_pipeline(scan_id, target, outdir):
    scan_logs[scan_id].append(f"[{ts()}] Vuln-only pipeline started for: {target}")
    stages = [
        ("12_nuclei",        "Nuclei — Template Scanning"),
        ("13_dalfox_sqlmap", "XSS + SQLi (dalfox + sqlmap)"),
        ("14_nikto",         "Server Audit (nikto)"),
        ("15_cors",          "CORS Misconfiguration (corscanner)"),
        ("19_waf",           "WAF Detection (wafw00f)"),
    ]
    _run_pipeline(scan_id, target, outdir, stages)

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/scan", methods=["POST"])
def start_scan():
    data   = request.get_json(force=True)
    target = data.get("target", "").strip()
    if not target:
        return jsonify({"error": "No target provided"}), 400
    scan_id            = f"scan_{int(time.time() * 1000)}"
    scan_logs[scan_id] = []
    scan_stop[scan_id] = threading.Event()
    threading.Thread(target=full_pipeline, args=(scan_id, target), daemon=True).start()
    return jsonify({"scan_id": scan_id})


@app.route("/status/<scan_id>")
def scan_status_route(scan_id):
    status      = scan_status.get(scan_id, {})
    from_offset = int(request.args.get("from", 0))
    logs        = scan_logs.get(scan_id, [])
    return jsonify({
        "status":     status.get("status", "unknown"),
        "current":    status.get("current", ""),
        "progress":   status.get("progress", 0),
        "outdir":     status.get("outdir", ""),
        "new_logs":   logs[from_offset:],
        "log_offset": len(logs),
    })


@app.route("/stop/<scan_id>", methods=["POST"])
def stop_scan(scan_id):
    ev = scan_stop.get(scan_id)
    if ev:
        ev.set()
    proc = scan_procs.get(scan_id)
    if proc:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except Exception:
            pass
    return jsonify({"ok": True})


@app.route("/vuln-only", methods=["POST"])
def vuln_only():
    target = request.form.get("target", "").strip()
    if not target:
        return jsonify({"error": "No target provided"}), 400

    domain_folder = f"{sanitize_domain(target)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_vuln"
    outdir        = os.path.join(OUTPUTS_DIR, domain_folder)
    os.makedirs(outdir, exist_ok=True)

    for field, fname in {"live": "live.txt", "gf_xss": "gf_xss.txt",
                         "gf_sqli": "gf_sqli.txt", "final_paramurls": "final_paramurls.txt"}.items():
        f = request.files.get(field)
        if f and f.filename:
            f.save(os.path.join(outdir, fname))

    scan_id            = f"scan_{int(time.time() * 1000)}"
    scan_logs[scan_id] = []
    scan_status[scan_id] = {"status": "running", "current": "Initializing vuln-only scan...",
                            "progress": 0, "outdir": domain_folder}
    scan_stop[scan_id] = threading.Event()
    threading.Thread(target=vuln_pipeline, args=(scan_id, target, outdir), daemon=True).start()
    return jsonify({"scan_id": scan_id})


@app.route("/clear-outputs", methods=["POST"])
def clear_outputs():
    try:
        if os.path.exists(OUTPUTS_DIR):
            shutil.rmtree(OUTPUTS_DIR)
        os.makedirs(OUTPUTS_DIR, exist_ok=True)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/file-content/<path:filename>")
def file_content(filename):
    fpath = os.path.join(OUTPUTS_DIR, filename)
    try:
        with open(fpath, "r", errors="replace") as f:
            return jsonify({"content": f.read(500_000)})
    except Exception:
        return jsonify({"content": "File not readable or empty."})


@app.route("/generate-report/<path:outdir>")
def generate_combined_report(outdir):
    base       = os.path.join(OUTPUTS_DIR, outdir)
    mode       = request.args.get("mode", "full")
    target     = request.args.get("target", outdir)
    now        = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    mode_label = "Full Scan" if mode == "full" else "Vuln-Only Scan"

    sections_html = ""
    if mode == "full":
        for title, icon, fname, empty in [
            ("Live Subdomains",                "🌐", "live.txt",            "live.txt not found or empty."),
            ("Technology Detection (WhatWeb)", "🔍", "whatweb.txt",         "whatweb.txt not found or empty."),
            ("Open Ports (Nmap)",              "🔌", "nmap.txt",            "nmap.txt not found or empty."),
            ("Subdomain Takeover",             "⚠️", "takeover.txt",        "takeover.txt not found or empty."),
            ("Filtered URLs",                  "🔗", "filtered_urls.txt",   "filtered_urls.txt not found or empty."),
            ("JS Files",                       "📜", "jsfiles.txt",         "jsfiles.txt not found or empty."),
            ("SecretFinder — JS Secrets",      "🔑", "js_secrets.txt",      "js_secrets.txt not found or empty."),
            ("Gitleaks — Secret Scan",         "🔓", "gitleaks.txt",        "gitleaks.txt not found or empty."),
            ("Parameters Discovered",          "🧩", "total_params.txt",    "total_params.txt not found or empty."),
            ("Final Parameter URLs",           "🎯", "final_paramurls.txt", "final_paramurls.txt not found or empty."),
        ]:
            sections_html += _section(title, icon, _read_file(os.path.join(base, fname)), empty)

    for title, icon, fname, empty in [
        ("Nuclei Results",       "🧬", "nuclei.txt", "nuclei.txt not found or empty."),
        ("Dalfox — XSS Results", "💉", "dalfox.txt", "dalfox.txt not found or empty."),
        ("SQLMap Results",       "🗄️", "sqlmap.txt", "sqlmap.txt not found or empty."),
        ("Wapiti Results",       "🕷️", "wapiti.txt", "wapiti.txt not found or empty."),
        ("Nikto Results",        "🔎", "nikto.txt",  "nikto.txt not found or empty."),
        ("CORScanner Results",   "🌍", "cors.txt",   "cors.txt not found or empty."),
        ("WAF Detection",        "🛡️", "waf.txt",    "waf.txt not found or empty."),
    ]:
        sections_html += _section(title, icon, _read_file(os.path.join(base, fname)), empty)

    html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<title>Scan Report — {target}</title>
<style>
body{{margin:0;padding:28px 32px;background:#0d1117;color:#e6edf3;font-family:'Segoe UI',Arial,sans-serif;font-size:13px;line-height:1.6}}
h1{{color:#58a6ff;font-size:22px;margin:0 0 4px}}
.meta{{color:#8b949e;font-size:12px;margin-bottom:30px}}
.section{{margin-bottom:32px;border:1px solid #21262d;border-radius:10px;overflow:hidden}}
.section h2{{margin:0;padding:13px 18px;background:#161b22;font-size:13px;font-weight:700;border-bottom:1px solid #21262d}}
pre{{margin:0;padding:16px 18px;white-space:pre-wrap;word-break:break-all;font-family:'Fira Mono','Consolas',monospace;font-size:12px;max-height:480px;overflow-y:auto;background:#0d1117}}
.empty{{color:#8b949e;padding:14px 18px;margin:0;font-style:italic}}
.badge{{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700;margin-left:8px;background:rgba(88,166,255,.15);color:#58a6ff}}
</style></head>
<body>
<h1>🔐 Security Scan Report <span class="badge">{mode_label}</span></h1>
<div class="meta">Target: <strong>{target}</strong> &nbsp;·&nbsp; Output dir: <code>{outdir}</code> &nbsp;·&nbsp; Generated: {now}</div>
{sections_html}
</body></html>"""

    return Response(html, mimetype="text/html",
                    headers={"Content-Disposition": f'attachment; filename="report_{outdir}.html"'})


@app.route("/generate-pdf/<path:outdir>")
def generate_pdf_report(outdir):
    base   = os.path.join(OUTPUTS_DIR, outdir)
    mode   = request.args.get("mode", "full")
    target = request.args.get("target", outdir)

    if not os.path.isdir(base):
        return jsonify({"error": "Output directory not found"}), 404

    pdf_path = os.path.join(base, f"report_{outdir}.pdf")
    try:
        _generate_pdf(base, mode=mode, target=target, output_path=pdf_path)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return send_file(
        pdf_path,
        mimetype="application/pdf",
        as_attachment=True,
        download_name=f"report_{outdir}.pdf"
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
