#!/bin/bash
# Stage 03: Technology Detection
# Tools:  whatweb
# Input:  live.txt
# Output: whatweb.txt

TARGET=$1
OUTDIR=$2

WHATWEB_BIN=""
for candidate in \
    "/usr/bin/whatweb" \
    "/usr/local/bin/whatweb" \
    "$(which whatweb 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then WHATWEB_BIN="$candidate"; break; fi
done

if [ -z "$WHATWEB_BIN" ]; then
    echo "[whatweb] ERROR: whatweb not found. Install: sudo apt install whatweb"
    touch "$OUTDIR/whatweb.txt"
    exit 0
fi

echo "[whatweb] Running tech detection on live hosts..."
touch "$OUTDIR/whatweb.txt"

if [ ! -f "$OUTDIR/live.txt" ] || [ ! -s "$OUTDIR/live.txt" ]; then
    echo "[whatweb] live.txt empty, scanning target directly"
    "$WHATWEB_BIN" --color=never "https://$TARGET" 2>&1 | tee "$OUTDIR/whatweb.txt"
else
    while IFS= read -r url; do
        [ -z "$url" ] && continue
        echo "--- $url ---"
        "$WHATWEB_BIN" --color=never "$url" 2>&1
        echo ""
    done < "$OUTDIR/live.txt" | tee "$OUTDIR/whatweb.txt"
fi

echo "[whatweb] Done. Saved: $OUTDIR/whatweb.txt"
