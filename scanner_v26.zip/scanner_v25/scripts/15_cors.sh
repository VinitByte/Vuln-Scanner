#!/bin/bash
# Stage 15: CORS Misconfiguration
# Input:  target URL
# Output: cors.txt

TARGET=$1
OUTDIR=$2

echo "[cors] Starting CORS scan..."
touch "$OUTDIR/cors.txt"

if echo "$TARGET" | grep -qE '^https?://'; then
    FULL_URL="$TARGET"
else
    FULL_URL="https://$TARGET"
fi

CORS_SCRIPT="$HOME/CORScanner/cors_scan.py"

if [ ! -f "$CORS_SCRIPT" ]; then
    echo "[cors] CORScanner not found — using curl fallback"

    {
        echo "=== CORS Check: $FULL_URL ==="
        echo ""

        echo "[*] Test 1 — Arbitrary origin (https://evil.com):"
        curl -s -I -H "Origin: https://evil.com" "$FULL_URL" 2>/dev/null \
            | grep -i "access-control" || echo "  No CORS headers found"
        echo ""

        echo "[*] Test 2 — Null origin:"
        curl -s -I -H "Origin: null" "$FULL_URL" 2>/dev/null \
            | grep -i "access-control" || echo "  No CORS headers found"
        echo ""

        DOMAIN=$(echo "$FULL_URL" | sed 's|https\?://||' | cut -d'/' -f1)
        echo "[*] Test 3 — Subdomain origin (https://evil.$DOMAIN):"
        curl -s -I -H "Origin: https://evil.$DOMAIN" "$FULL_URL" 2>/dev/null \
            | grep -i "access-control" || echo "  No CORS headers found"

    } 2>&1 | tee "$OUTDIR/cors.txt"

else
    echo "[cors] Using CORScanner: $CORS_SCRIPT"
    python3 -c "import tldextract; tldextract.extract('example.com')" 2>/dev/null || true
    python3 "$CORS_SCRIPT" -u "$FULL_URL" -v 2>&1 | tee "$OUTDIR/cors.txt"
fi

echo ""
echo "[cors] Done. Saved: $OUTDIR/cors.txt ($(wc -l < "$OUTDIR/cors.txt") lines)"
