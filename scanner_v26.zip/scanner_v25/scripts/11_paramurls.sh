#!/bin/bash
# Stage 11: Build paramurls1.txt, paramurls2.txt → final_paramurls.txt
#
# ┌──────────────────────────────────────────────────────────────────────────┐
# │  PRE-STEP: Build split files (done HERE, AFTER paramspider/arjun ran)   │
# │                                                                          │
# │    urls_with_params.txt  =                                               │
# │        filtered_urls (with ?=) + paramspider.txt                        │
# │        → combined + deduplicated                                         │
# │                                                                          │
# │    urls_without_params.txt =                                             │
# │        filtered_urls with no query string                                │
# ├──────────────────────────────────────────────────────────────────────────┤
# │  PIPELINE 1  (URLs with params → paramurls1.txt)                        │
# │    urls_with_params.txt                                                  │
# │      → live filter                                                       │
# │      → value fuzzing (ffuf)                                              │
# │      → paramurls1.txt                                                   │
# ├──────────────────────────────────────────────────────────────────────────┤
# │  PIPELINE 2  (URLs without params → paramurls2.txt)                     │
# │    urls_without_params.txt                                               │
# │      → ffuf dir bruteforce (SecLists) → discovered paths                │
# │      → total_endpoints.txt:                                              │
# │            ffuf discovered paths                                         │
# │          + js_endpoints.txt (linkfinder output)                          │
# │          + paths.txt (unfurl from stage 07)                              │
# │      → build full URLs (live hosts × total_endpoints)                   │
# │      → live filter                                                       │
# │      → param fuzzing using combined param wordlist:                      │
# │            SecLists burp-parameter-names                                 │
# │          + arjun_params.txt (stage 10)                                  │
# │          + params_keys.txt (unfurl from stage 07)                       │
# │          → combined + deduplicated as single wordlist                    │
# │      → value fuzzing                                                     │
# │      → paramurls2.txt                                                   │
# ├──────────────────────────────────────────────────────────────────────────┤
# │  FINAL MERGE                                                             │
# │    paramurls1.txt + paramurls2.txt → dedup → final_paramurls.txt        │
# │    → gf patterns: gf_xss.txt gf_sqli.txt                                │
# └──────────────────────────────────────────────────────────────────────────┘
#
# Tools:  httpx, ffuf, gf
# Inputs: filtered_urls.txt, paramspider.txt, js_endpoints.txt,
#         paths.txt, params_keys.txt, arjun_params.txt, live.txt

TARGET=$1
OUTDIR=$2

echo "[paramurls] ============================================================"
echo "[paramurls] Building paramurls1.txt + paramurls2.txt → final_paramurls.txt"
echo "[paramurls] ============================================================"

touch "$OUTDIR/urls_with_params.txt" \
      "$OUTDIR/urls_without_params.txt" \
      "$OUTDIR/total_endpoints.txt" \
      "$OUTDIR/paramurls1.txt" \
      "$OUTDIR/paramurls2.txt" \
      "$OUTDIR/final_paramurls.txt" \
      "$OUTDIR/gf_xss.txt" "$OUTDIR/gf_sqli.txt"

# ── Resolve binaries ──────────────────────────────────────────────────────────
resolve_bin() {
    local varname=$1; shift
    for candidate in "$@"; do
        if [ -x "$candidate" ] 2>/dev/null; then
            eval "$varname=\"$candidate\""
            return
        fi
    done
}

resolve_bin HTTPX_BIN \
    "$HOME/go/bin/httpx" "/usr/local/bin/httpx" "/usr/bin/httpx" "$(which httpx 2>/dev/null)"
resolve_bin FFUF_BIN \
    "$HOME/go/bin/ffuf" "/usr/local/bin/ffuf" "/usr/bin/ffuf" "$(which ffuf 2>/dev/null)"
resolve_bin GF_BIN \
    "$HOME/go/bin/gf" "/usr/local/bin/gf" "/usr/bin/gf" "$(which gf 2>/dev/null)"

[ -z "$HTTPX_BIN" ] && echo "[httpx] WARNING: httpx not found — live filtering will be skipped"
[ -z "$FFUF_BIN" ]  && echo "[ffuf]  WARNING: ffuf not found — fuzzing steps will be skipped"

# ── Wordlists ─────────────────────────────────────────────────────────────────

# Directory bruteforce wordlist (SecLists)
resolve_dir_wl() {
    for f in \
        "/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt" \
        "/usr/share/seclists/Discovery/Web-Content/directory-list-2.3-medium.txt" \
        "/usr/share/seclists/Discovery/Web-Content/common.txt" \
        "/usr/share/wordlists/dirb/common.txt"
    do
        [ -f "$f" ] && { echo "$f"; return; }
    done
    local f="/tmp/fallback_dirs_$$.txt"
    printf "admin\napi\nlogin\ndashboard\nstatic\nassets\njs\ncss\nbackup\nconfig\ntest\ndev\nstaging\nv1\nv2\n" > "$f"
    echo "$f"
}
DIR_WL=$(resolve_dir_wl)
echo "[paramurls] Dir bruteforce wordlist: $DIR_WL"

# ── Parameter fuzzing wordlist ─────────────────────────────────────────────────
# Sources (combined + deduplicated):
#   1. SecLists burp-parameter-names.txt
#   2. arjun_params.txt  (discovered by arjun in stage 10)
#   3. params_keys.txt   (unfurl keys from stage 07)
build_param_wl() {
    local SECLISTS_PARAMS=""
    for f in \
        "/usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt" \
        "/usr/share/seclists/Discovery/Web-Content/common.txt"
    do
        [ -f "$f" ] && { SECLISTS_PARAMS="$f"; break; }
    done

    local COMBINED="/tmp/param_wl_combined_$$.txt"
    > "$COMBINED"

    # Source 1: SecLists
    if [ -n "$SECLISTS_PARAMS" ]; then
        cat "$SECLISTS_PARAMS" >> "$COMBINED"
        echo "[paramurls] Param WL source 1 — SecLists: $(wc -l < "$SECLISTS_PARAMS") entries" >&2
    else
        echo "[paramurls] Param WL source 1 — SecLists: NOT FOUND (skipped)" >&2
    fi

    # Source 2: arjun_params.txt
    if [ -s "$OUTDIR/arjun_params.txt" ]; then
        cat "$OUTDIR/arjun_params.txt" >> "$COMBINED"
        echo "[paramurls] Param WL source 2 — arjun_params.txt: $(wc -l < "$OUTDIR/arjun_params.txt") entries" >&2
    else
        echo "[paramurls] Param WL source 2 — arjun_params.txt: empty/not found (skipped)" >&2
    fi

    # Source 3: params_keys.txt (unfurl keys from stage 07)
    if [ -s "$OUTDIR/params_keys.txt" ]; then
        cat "$OUTDIR/params_keys.txt" >> "$COMBINED"
        echo "[paramurls] Param WL source 3 — params_keys.txt (unfurl): $(wc -l < "$OUTDIR/params_keys.txt") entries" >&2
    else
        echo "[paramurls] Param WL source 3 — params_keys.txt: empty/not found (skipped)" >&2
    fi

    # Fallback if still empty
    if [ ! -s "$COMBINED" ]; then
        printf "id\npage\nq\nsearch\nquery\nname\nuser\nfile\npath\ntoken\nredirect\nurl\ncat\ntype\nview\n" > "$COMBINED"
        echo "[paramurls] Param WL: all sources empty — using minimal fallback" >&2
    fi

    sort -u "$COMBINED" -o "$COMBINED"
    echo "$COMBINED"
}
PARAM_WL=$(build_param_wl)
echo "[paramurls] Final param fuzzing wordlist: $PARAM_WL ($(wc -l < "$PARAM_WL") unique entries)"
echo "[paramurls]   (SecLists burp-parameter-names + arjun_params.txt + params_keys.txt → combined + deduped)"

# ── Helper: live_filter ───────────────────────────────────────────────────────
live_filter() {
    local infile=$1 outfile=$2
    if [ -n "$HTTPX_BIN" ] && [ -s "$infile" ]; then
        "$HTTPX_BIN" -l "$infile" -silent -mc 200,301,302,403 2>/dev/null > "$outfile"
    else
        [ -s "$infile" ] && cp "$infile" "$outfile" || touch "$outfile"
    fi
}

# ── Helper: value_fuzz ────────────────────────────────────────────────────────
value_fuzz() {
    local infile=$1 outfile=$2 maxurls=${3:-50}
    [ -z "$FFUF_BIN" ] && { echo "[value-fuzz] ffuf not found — skipping"; return; }
    [ ! -s "$infile" ] && return

    local VF_TMP="/tmp/vf_out_$$.txt"
    > "$VF_TMP"

    while IFS= read -r url; do
        [ -z "$url" ] && continue

        python3 - "$url" 2>/dev/null << 'PYEOF' | while IFS= read -r fuzz_url; do
import sys
from urllib.parse import urlparse, parse_qs, urlencode

url = sys.argv[1].strip()
p = urlparse(url)
qs = parse_qs(p.query, keep_blank_values=True)
if not qs:
    sys.exit(0)
for key in qs:
    new_qs = dict(qs)
    new_qs[key] = ['FUZZ']
    encoded = urlencode({k: v[0] for k, v in new_qs.items()})
    print(f"{p.scheme}://{p.netloc}{p.path}?{encoded}")
PYEOF
            FFUF_JSON="/tmp/ffuf_vf_$$.json"
            "$FFUF_BIN" \
                -u "$fuzz_url" \
                -w /dev/null \
                -input-cmd 'printf "test\n<script>alert(1)</script>\n1 OR 1=1\n../etc/passwd\n"' \
                -mc 200,204,301,302,307,401,403 \
                -t 20 -timeout 10 \
                -o "$FFUF_JSON" -of json -s 2>/dev/null || true

            python3 - "$FFUF_JSON" "$fuzz_url" >> "$VF_TMP" 2>/dev/null << 'PYEOF'
import json, sys
from urllib.parse import urlparse, parse_qs, urlencode
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    fuzz_url = sys.argv[2]
    p = urlparse(fuzz_url)
    qs = parse_qs(p.query, keep_blank_values=True)
    fuzz_key = next((k for k, v in qs.items() if v == ['FUZZ']), None)
    for r in d.get("results", []):
        val = r.get("input", {}).get("FUZZ", "")
        if val and fuzz_key:
            new_qs = dict(qs)
            new_qs[fuzz_key] = [val]
            encoded = urlencode({k: v[0] for k, v in new_qs.items()})
            print(f"{p.scheme}://{p.netloc}{p.path}?{encoded}")
except:
    pass
PYEOF
            rm -f "$FFUF_JSON"
        done

    done < <(head -"$maxurls" "$infile")

    # Always include original input URLs (regardless of ffuf results)
    cat "$infile" >> "$outfile"
    sort -u "$VF_TMP" >> "$outfile"
    rm -f "$VF_TMP"
}

# ════════════════════════════════════════════════════════════════════════════════
# PRE-STEP: Build urls_with_params.txt and urls_without_params.txt
#           Done HERE (after paramspider/arjun ran in stage 10)
# ════════════════════════════════════════════════════════════════════════════════
echo ""
echo "[paramurls] ── PRE-STEP: Splitting filtered_urls.txt + paramspider ───────"

# urls_with_params.txt:
#   Source 1: filtered_urls.txt entries that have query parameters (?key=val)
#   Source 2: paramspider.txt output (already has params)
# → combine + deduplicate
{
    grep "?.*=" "$OUTDIR/filtered_urls.txt" 2>/dev/null
    grep "^http" "$OUTDIR/paramspider.txt"  2>/dev/null | grep "="
} | sort -u > "$OUTDIR/urls_with_params.txt"

echo "[paramurls] urls_with_params.txt: $(wc -l < "$OUTDIR/urls_with_params.txt") URLs"
echo "[paramurls]   Sources: filtered_urls.txt (param URLs) + paramspider.txt → combined + deduped"

# urls_without_params.txt:
#   filtered_urls.txt entries with NO query string at all
grep -v "?" "$OUTDIR/filtered_urls.txt" 2>/dev/null | sort -u > "$OUTDIR/urls_without_params.txt"
echo "[paramurls] urls_without_params.txt: $(wc -l < "$OUTDIR/urls_without_params.txt") URLs"
echo "[paramurls]   Source: filtered_urls.txt (clean URLs only)"

# ════════════════════════════════════════════════════════════════════════════════
# PIPELINE 1 — URLs WITH params → paramurls1.txt
# ════════════════════════════════════════════════════════════════════════════════
echo ""
echo "[paramurls] ── PIPELINE 1: URLs with params ─────────────────────────────"

# Step 1a: Live filter
P1_LIVE="/tmp/p1_live_$$.txt"
live_filter "$OUTDIR/urls_with_params.txt" "$P1_LIVE"
echo "[pipeline1] After live filter: $(wc -l < "$P1_LIVE") URLs"

# Step 1b: Write live filtered URLs directly into paramurls1.txt
echo "[pipeline1] Adding live filtered urls_with_params URLs to paramurls1.txt..."
cat "$P1_LIVE" >> "$OUTDIR/paramurls1.txt"
echo "[pipeline1] Live URLs added: $(wc -l < "$P1_LIVE") URLs"

# Step 1c: Value fuzzing on live parameterized URLs (appends fuzzed variations)
echo "[pipeline1] Running value fuzzing on live param URLs..."
value_fuzz "$P1_LIVE" "$OUTDIR/paramurls1.txt" 60

sort -u "$OUTDIR/paramurls1.txt" -o "$OUTDIR/paramurls1.txt"
echo "[pipeline1] paramurls1.txt: $(wc -l < "$OUTDIR/paramurls1.txt") URLs"
rm -f "$P1_LIVE"

# ════════════════════════════════════════════════════════════════════════════════
# PIPELINE 2 — URLs WITHOUT params → paramurls2.txt
# ════════════════════════════════════════════════════════════════════════════════
echo ""
echo "[paramurls] ── PIPELINE 2: URLs without params ──────────────────────────"

# Determine base hosts for building full URLs from endpoints
BASE_HOSTS=()
if [ -f "$OUTDIR/live.txt" ] && [ -s "$OUTDIR/live.txt" ]; then
    while IFS= read -r h; do
        BASE_HOSTS+=("${h%/}")
    done < <(head -5 "$OUTDIR/live.txt")
fi
PRIMARY_HOST="${BASE_HOSTS[0]:-}"
echo "[pipeline2] Base hosts: ${BASE_HOSTS[*]:-none}"

# ── Step 2a: Dir bruteforce on urls_without_params targets ───────────────────
echo "[pipeline2] Step 2a: Directory bruteforce (ffuf + SecLists)..."
P2_DISCOVERED_PATHS="/tmp/p2_discovered_paths_$$.txt"
> "$P2_DISCOVERED_PATHS"

if [ -z "$FFUF_BIN" ]; then
    echo "[pipeline2] ffuf not found — skipping dir bruteforce"
elif [ ! -s "$OUTDIR/urls_without_params.txt" ]; then
    echo "[pipeline2] urls_without_params.txt empty — skipping dir bruteforce"
else
    # Extract unique base origins (scheme://host) from urls_without_params
    P2_BASES="/tmp/p2_bases_$$.txt"
    python3 - "$OUTDIR/urls_without_params.txt" > "$P2_BASES" 2>/dev/null << 'PYEOF'
import sys
from urllib.parse import urlparse
seen = set()
with open(sys.argv[1]) as f:
    for line in f:
        url = line.strip()
        if not url:
            continue
        p = urlparse(url)
        base = f"{p.scheme}://{p.netloc}"
        if base not in seen:
            seen.add(base)
            print(base)
PYEOF

    while IFS= read -r base_url; do
        [ -z "$base_url" ] && continue
        echo "[pipeline2] Dir bruteforce: $base_url"
        FFUF_DIR_JSON="/tmp/ffuf_dir_$$.json"

        "$FFUF_BIN" \
            -u "${base_url}/FUZZ" \
            -w "$DIR_WL" \
            -mc 200,204,301,302,307,401,403 \
            -t 40 -timeout 10 \
            -o "$FFUF_DIR_JSON" -of json -s \
            2>/dev/null || true

        python3 - "$FFUF_DIR_JSON" >> "$P2_DISCOVERED_PATHS" 2>/dev/null << 'PYEOF'
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    for r in d.get("results", []):
        word = r.get("input", {}).get("FUZZ", "")
        if word:
            print(f"/{word}")
except:
    pass
PYEOF
        rm -f "$FFUF_DIR_JSON"
    done < <(head -10 "$P2_BASES")

    sort -u "$P2_DISCOVERED_PATHS" -o "$P2_DISCOVERED_PATHS"
    echo "[pipeline2] Dir bruteforce discovered: $(wc -l < "$P2_DISCOVERED_PATHS") unique paths"
    rm -f "$P2_BASES"
fi

# ── Step 2b: Build total_endpoints.txt ───────────────────────────────────────
# Sources:
#   1. ffuf dir bruteforce discovered paths (Step 2a)
#   2. js_endpoints.txt  → linkfinder output (stage 09)
#   3. paths.txt         → unfurl paths (stage 07)
# → path portion extracted, combined, deduplicated
echo "[pipeline2] Step 2b: Building total_endpoints.txt..."
P2_ALL_PATHS="/tmp/p2_all_paths_$$.txt"
> "$P2_ALL_PATHS"

# Source 1: ffuf discovered paths
if [ -s "$P2_DISCOVERED_PATHS" ]; then
    cat "$P2_DISCOVERED_PATHS" >> "$P2_ALL_PATHS"
    echo "[pipeline2]   Source 1 — ffuf dir bruteforce: $(wc -l < "$P2_DISCOVERED_PATHS") paths"
fi

# Source 2: js_endpoints.txt (linkfinder) — extract path portion
if [ -s "$OUTDIR/js_endpoints.txt" ]; then
    python3 - "$OUTDIR/js_endpoints.txt" >> "$P2_ALL_PATHS" 2>/dev/null << 'PYEOF'
import sys
from urllib.parse import urlparse
with open(sys.argv[1]) as f:
    for line in f:
        ep = line.strip()
        if not ep:
            continue
        if ep.startswith("http"):
            p = urlparse(ep)
            if p.path and p.path != "/":
                print(p.path)
        elif ep.startswith("/"):
            print(ep)
        else:
            print(f"/{ep}")
PYEOF
    echo "[pipeline2]   Source 2 — js_endpoints.txt (linkfinder): $(wc -l < "$OUTDIR/js_endpoints.txt") endpoints added"
fi

# Source 3: paths.txt (unfurl from stage 07)
if [ -s "$OUTDIR/paths.txt" ]; then
    cat "$OUTDIR/paths.txt" >> "$P2_ALL_PATHS"
    echo "[pipeline2]   Source 3 — paths.txt (unfurl): $(wc -l < "$OUTDIR/paths.txt") paths added"
fi

sort -u "$P2_ALL_PATHS" -o "$P2_ALL_PATHS"
echo "[pipeline2] Total unique paths collected: $(wc -l < "$P2_ALL_PATHS")"

# Save as total_endpoints.txt
cp "$P2_ALL_PATHS" "$OUTDIR/total_endpoints.txt"
echo "[pipeline2] Saved: total_endpoints.txt ($(wc -l < "$OUTDIR/total_endpoints.txt") paths)"

# ── Step 2c: Build full URLs from total_endpoints × base hosts ───────────────
echo "[pipeline2] Step 2c: Building full URLs (live hosts × total_endpoints)..."
P2_FULL_URLS="/tmp/p2_full_urls_$$.txt"
> "$P2_FULL_URLS"

if [ ${#BASE_HOSTS[@]} -eq 0 ]; then
    echo "[pipeline2] WARNING: No live hosts — cannot build full URLs for pipeline 2"
else
    while IFS= read -r path; do
        [ -z "$path" ] && continue
        for host in "${BASE_HOSTS[@]}"; do
            echo "${host%/}/${path#/}"
        done
    done < "$P2_ALL_PATHS" | sort -u >> "$P2_FULL_URLS"
fi
echo "[pipeline2] Full URLs built: $(wc -l < "$P2_FULL_URLS")"

# ── Step 2d: Live filter ──────────────────────────────────────────────────────
echo "[pipeline2] Step 2d: Live filtering full URLs..."
P2_LIVE="/tmp/p2_live_$$.txt"
live_filter "$P2_FULL_URLS" "$P2_LIVE"
echo "[pipeline2] After live filter: $(wc -l < "$P2_LIVE") live endpoints"

# ── Step 2e: Param fuzzing on live endpoints ──────────────────────────────────
# Wordlist = PARAM_WL (SecLists + arjun_params.txt + params_keys.txt, built above)
echo "[pipeline2] Step 2e: Parameter fuzzing..."
echo "[pipeline2]   Wordlist: $PARAM_WL ($(wc -l < "$PARAM_WL") entries)"
echo "[pipeline2]   Sources: SecLists burp-parameter-names + arjun_params.txt + params_keys.txt"
P2_PARAMFUZZ_OUT="/tmp/p2_paramfuzz_$$.txt"
> "$P2_PARAMFUZZ_OUT"

if [ -z "$FFUF_BIN" ]; then
    echo "[pipeline2] ffuf not found — skipping param fuzzing"
elif [ ! -s "$P2_LIVE" ]; then
    echo "[pipeline2] No live endpoints — skipping param fuzzing"
else
    while IFS= read -r url; do
        [ -z "$url" ] && continue
        FFUF_PF_JSON="/tmp/ffuf_pf_$$.json"

        "$FFUF_BIN" \
            -u "${url}?FUZZ=1" \
            -w "$PARAM_WL" \
            -mc 200,204,301,302,307,401,403 \
            -t 30 -timeout 10 \
            -o "$FFUF_PF_JSON" -of json -s \
            2>/dev/null || true

        python3 - "$FFUF_PF_JSON" "$url" >> "$P2_PARAMFUZZ_OUT" 2>/dev/null << 'PYEOF'
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    base = sys.argv[2].rstrip("?")
    for r in d.get("results", []):
        word = r.get("input", {}).get("FUZZ", "")
        if word:
            print(f"{base}?{word}=1")
except:
    pass
PYEOF
        rm -f "$FFUF_PF_JSON"
    done < <(head -40 "$P2_LIVE")

    sort -u "$P2_PARAMFUZZ_OUT" -o "$P2_PARAMFUZZ_OUT"
    echo "[pipeline2] Param fuzzing discovered: $(wc -l < "$P2_PARAMFUZZ_OUT") param URLs"
fi

# ── Step 2f: Value fuzzing on param-discovered URLs ───────────────────────────
echo "[pipeline2] Step 2f: Value fuzzing on param-fuzzed URLs..."
cat "$P2_PARAMFUZZ_OUT" >> "$OUTDIR/paramurls2.txt"
value_fuzz "$P2_PARAMFUZZ_OUT" "$OUTDIR/paramurls2.txt" 50

sort -u "$OUTDIR/paramurls2.txt" -o "$OUTDIR/paramurls2.txt"
echo "[pipeline2] paramurls2.txt: $(wc -l < "$OUTDIR/paramurls2.txt") URLs"

# Cleanup pipeline 2 temps
rm -f "$P2_DISCOVERED_PATHS" "$P2_ALL_PATHS" "$P2_FULL_URLS" \
      "$P2_LIVE" "$P2_PARAMFUZZ_OUT"

# ════════════════════════════════════════════════════════════════════════════════
# FINAL MERGE → final_paramurls.txt
# ════════════════════════════════════════════════════════════════════════════════
echo ""
echo "[paramurls] ── FINAL MERGE ───────────────────────────────────────────────"

cat "$OUTDIR/paramurls1.txt" "$OUTDIR/paramurls2.txt" 2>/dev/null \
    | grep "^http" | grep "=" \
    | sort -u > "$OUTDIR/final_paramurls.txt"

TOTAL=$(wc -l < "$OUTDIR/final_paramurls.txt")
echo "[paramurls] paramurls1.txt     : $(wc -l < "$OUTDIR/paramurls1.txt") URLs"
echo "[paramurls] paramurls2.txt     : $(wc -l < "$OUTDIR/paramurls2.txt") URLs"
echo "[paramurls] final_paramurls.txt: $TOTAL unique parameterized URLs (final)"

# Cleanup wordlist temps
echo "$PARAM_WL" | grep -q "^/tmp/" && rm -f "$PARAM_WL"
echo "$DIR_WL"   | grep -q "^/tmp/" && rm -f "$DIR_WL"

# ── Live filter final_paramurls.txt before GF ────────────────────────────────
echo ""
echo "[paramurls] ── LIVE FILTER final_paramurls.txt before GF ────────────────"

LIVE_PARAMURLS="$OUTDIR/final_paramurls.txt"

if [ -n "$HTTPX_BIN" ] && [ -s "$OUTDIR/final_paramurls.txt" ]; then
    echo "[paramurls] Running httpx live filter on final_paramurls.txt..."
    LIVE_PARAMURLS_TMP="/tmp/live_paramurls_$$.txt"

    "$HTTPX_BIN" \
        -l "$OUTDIR/final_paramurls.txt" \
        -silent \
        -mc 200,301,302,403 \
        2>/dev/null > "$LIVE_PARAMURLS_TMP"

    LIVE_COUNT=$(wc -l < "$LIVE_PARAMURLS_TMP")
    echo "[paramurls] Live paramurls: $LIVE_COUNT / $TOTAL"

    if [ "$LIVE_COUNT" -gt 0 ]; then
        # Save as live_paramurls.txt and use for GF
        sort -u "$LIVE_PARAMURLS_TMP" > "$OUTDIR/live_paramurls.txt"
        LIVE_PARAMURLS="$OUTDIR/live_paramurls.txt"
        echo "[paramurls] Saved: live_paramurls.txt ($LIVE_COUNT URLs) → used for GF"
    else
        echo "[paramurls] WARNING: No live URLs found — falling back to full final_paramurls.txt for GF"
        rm -f "$LIVE_PARAMURLS_TMP"
    fi
else
    [ -z "$HTTPX_BIN" ] && echo "[paramurls] httpx not found — skipping live filter, using full final_paramurls.txt for GF"
fi

# ── GF patterns on live_paramurls.txt (or final_paramurls fallback) ───────────
echo ""
echo "[gf] Running GF patterns on: $(basename "$LIVE_PARAMURLS") ($(wc -l < "$LIVE_PARAMURLS") URLs)"

if [ -z "$GF_BIN" ]; then
    echo "[gf] ERROR: gf not found. Install: go install github.com/tomnomnom/gf@latest"
else
    cat "$LIVE_PARAMURLS" | "$GF_BIN" xss  2>/dev/null | sort -u > "$OUTDIR/gf_xss.txt"
    cat "$LIVE_PARAMURLS" | "$GF_BIN" sqli 2>/dev/null | sort -u > "$OUTDIR/gf_sqli.txt"

    echo "[gf] gf_xss.txt:  $(wc -l < "$OUTDIR/gf_xss.txt") URLs  → for dalfox"
    echo "[gf] gf_sqli.txt: $(wc -l < "$OUTDIR/gf_sqli.txt") URLs  → for sqlmap"
fi

echo "[paramurls] Done."
