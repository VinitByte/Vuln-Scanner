#!/bin/bash
# Stage 04: Port Scanning
# Tools:  nmap
# Input:  live.txt
# Output: nmap.txt

TARGET=$1
OUTDIR=$2

echo "[nmap] Running port scan..."

if [ ! -f "$OUTDIR/live.txt" ] || [ ! -s "$OUTDIR/live.txt" ]; then
    echo "[nmap] live.txt empty, scanning target directly"
    nmap -sV -T4 --open "$TARGET" -oN "$OUTDIR/nmap.txt" 2>&1
else
    cat "$OUTDIR/live.txt" | sed 's|https\?://||' | cut -d'/' -f1 | sort -u > /tmp/nmap_hosts_$$.txt
    nmap -sV -T4 --open -iL /tmp/nmap_hosts_$$.txt -oN "$OUTDIR/nmap.txt" 2>&1
    rm -f /tmp/nmap_hosts_$$.txt
fi

touch "$OUTDIR/nmap.txt"
echo "[nmap] Saved: $OUTDIR/nmap.txt"
echo "[nmap] Done."
