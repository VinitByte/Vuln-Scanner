#!/bin/bash
# Stage 02: Live Host Detection
# Tools:  httpx
# Input:  subdomains.txt
# Output: live.txt

TARGET=$1
OUTDIR=$2

HTTPX_BIN=""
for candidate in \
    "$HOME/go/bin/httpx" \
    "/usr/local/bin/httpx" \
    "/usr/bin/httpx" \
    "$(which httpx 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then HTTPX_BIN="$candidate"; break; fi
done

if [ -z "$HTTPX_BIN" ]; then
    echo "[httpx] ERROR: httpx not found."
    echo "[httpx] Install: go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest"
    echo "https://$TARGET" > "$OUTDIR/live.txt"
    exit 0
fi

echo "[httpx] Probing live hosts from subdomains.txt..."

if [ ! -f "$OUTDIR/subdomains.txt" ] || [ ! -s "$OUTDIR/subdomains.txt" ]; then
    echo "[httpx] subdomains.txt empty, using target directly"
    echo "$TARGET" | "$HTTPX_BIN" -silent -o "$OUTDIR/live.txt" 2>&1
else
    "$HTTPX_BIN" -l "$OUTDIR/subdomains.txt" -silent -o "$OUTDIR/live.txt" 2>&1
fi

touch "$OUTDIR/live.txt"
COUNT=$(wc -l < "$OUTDIR/live.txt" 2>/dev/null || echo 0)
echo "[httpx] Saved: $OUTDIR/live.txt ($COUNT live hosts)"
echo "[httpx] Done."
