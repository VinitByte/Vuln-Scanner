#!/bin/bash
# Stage 01: Subdomain Enumeration
# Tools:  subfinder
# Input:  target ($1)
# Output: subdomains.txt

TARGET=$1
OUTDIR=$2

echo "[subfinder] Running subdomain enumeration on: $TARGET"

SUBFINDER_BIN=""
for candidate in \
    "$HOME/go/bin/subfinder" \
    "/usr/local/bin/subfinder" \
    "/usr/bin/subfinder" \
    "$(which subfinder 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then SUBFINDER_BIN="$candidate"; break; fi
done

if [ -z "$SUBFINDER_BIN" ]; then
    echo "[subfinder] ERROR: subfinder not found."
    echo "[subfinder] Install: go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    echo "$TARGET" > "$OUTDIR/subdomains.txt"
    exit 0
fi

DOMAIN=$(echo "$TARGET" | sed 's|^https\?://||' | cut -d'/' -f1)
echo "[subfinder] Using binary: $SUBFINDER_BIN"
"$SUBFINDER_BIN" -d "$DOMAIN" -o "$OUTDIR/subdomains.txt" -silent 2>&1

touch "$OUTDIR/subdomains.txt"
COUNT=$(wc -l < "$OUTDIR/subdomains.txt" 2>/dev/null || echo 0)
echo "[subfinder] Saved: $OUTDIR/subdomains.txt ($COUNT subdomains)"
echo "[subfinder] Done."
