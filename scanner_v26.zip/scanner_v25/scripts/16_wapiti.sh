#!/bin/bash
# Stage 16: Wapiti — Web Vulnerability Scanner
# Input:  target URL
# Output: wapiti.txt

TARGET=$1
OUTDIR=$2

if echo "$TARGET" | grep -qE '^https?://'; then
    FULL_URL="$TARGET"
else
    FULL_URL="https://$TARGET"
fi

touch "$OUTDIR/wapiti.txt"

echo "[wapiti] Scanning: $FULL_URL"

WAPITI_BIN=""
for candidate in "$(which wapiti 2>/dev/null)" "/usr/bin/wapiti" "/usr/local/bin/wapiti"; do
    [ -x "$candidate" ] 2>/dev/null && WAPITI_BIN="$candidate" && break
done

if [ -z "$WAPITI_BIN" ]; then
    echo "[wapiti] ERROR: wapiti not found. Install: pip install wapiti3"
else
    "$WAPITI_BIN" -u "$FULL_URL" -f txt -o "$OUTDIR/wapiti.txt" 2>&1
    echo "[wapiti] Done. Saved: $OUTDIR/wapiti.txt ($(wc -l < "$OUTDIR/wapiti.txt") lines)"
fi
