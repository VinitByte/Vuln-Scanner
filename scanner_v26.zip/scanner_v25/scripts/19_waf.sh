#!/bin/bash
# Stage 19: WAF Detection
# Input:  live.txt / target
# Output: waf.txt

TARGET=$1
OUTDIR=$2

echo "[wafw00f] Starting WAF detection..."
touch "$OUTDIR/waf.txt"

if echo "$TARGET" | grep -qE '^https?://'; then FULL_URL="$TARGET"; else FULL_URL="https://$TARGET"; fi

WAFW00F_BIN=""
for candidate in \
    "$HOME/.local/bin/wafw00f" \
    "/usr/local/bin/wafw00f" \
    "/usr/bin/wafw00f" \
    "$(which wafw00f 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then WAFW00F_BIN="$candidate"; break; fi
done

if [ -z "$WAFW00F_BIN" ]; then
    echo "[wafw00f] ERROR: wafw00f not found. Install: pip install wafw00f"
    exit 0
fi

echo "[wafw00f] Using binary: $WAFW00F_BIN"

if [ -f "$OUTDIR/live.txt" ] && [ -s "$OUTDIR/live.txt" ]; then
    echo "[wafw00f] Detecting WAF on live hosts..."
    while IFS= read -r url; do
        [ -z "$url" ] && continue
        echo "=== $url ==="
        "$WAFW00F_BIN" "$url" 2>&1 | tee -a "$OUTDIR/waf.txt"
        echo ""
    done < "$OUTDIR/live.txt"
else
    "$WAFW00F_BIN" "$FULL_URL" 2>&1 | tee "$OUTDIR/waf.txt"
fi

echo "[wafw00f] Done. Saved: $OUTDIR/waf.txt ($(wc -l < "$OUTDIR/waf.txt") lines)"
