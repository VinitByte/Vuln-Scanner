#!/bin/bash
# Stage 06: URL Collection
# Tools:  gau (--subs), katana
# Input:  live.txt, subdomains.txt
# Output: gau.txt, katana.txt, allurls.txt

TARGET=$1
OUTDIR=$2

echo "[url-collection] Starting URL collection (gau + katana)..."

DOMAIN=$(echo "$TARGET" | sed 's|^https\?://||' | cut -d'/' -f1)
touch "$OUTDIR/gau.txt" "$OUTDIR/katana.txt"

# ── GAU (with --subs) ─────────────────────────────────────────────────────────
GAU_BIN=""
for candidate in \
    "$HOME/go/bin/gau" \
    "/usr/local/bin/gau" \
    "/usr/bin/gau" \
    "$(which gau 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then GAU_BIN="$candidate"; break; fi
done

if [ -z "$GAU_BIN" ]; then
    echo "[gau] ERROR: gau not found. Install: go install github.com/lc/gau/v2/cmd/gau@latest"
else
    echo "[gau] Fetching historical URLs for: $DOMAIN (--subs)"
    "$GAU_BIN" --subs "$DOMAIN" 2>&1 | tee "$OUTDIR/gau.txt"
    echo "[gau] Saved: $OUTDIR/gau.txt ($(wc -l < "$OUTDIR/gau.txt") URLs)"
fi

# ── KATANA ────────────────────────────────────────────────────────────────────
KATANA_BIN=""
for candidate in \
    "$HOME/go/bin/katana" \
    "/usr/local/bin/katana" \
    "/usr/bin/katana" \
    "$(which katana 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then KATANA_BIN="$candidate"; break; fi
done

if [ -z "$KATANA_BIN" ]; then
    echo "[katana] ERROR: katana not found. Install: go install github.com/projectdiscovery/katana/cmd/katana@latest"
else
    echo "[katana] Crawling live hosts..."
    if [ -f "$OUTDIR/live.txt" ] && [ -s "$OUTDIR/live.txt" ]; then
        "$KATANA_BIN" -list "$OUTDIR/live.txt" -o "$OUTDIR/katana.txt" 2>&1
    else
        "$KATANA_BIN" -u "https://$TARGET" -o "$OUTDIR/katana.txt" 2>&1
    fi
    echo "[katana] Saved: $OUTDIR/katana.txt ($(wc -l < "$OUTDIR/katana.txt") URLs)"
fi

# ── MERGE → allurls.txt ───────────────────────────────────────────────────────
echo "[url-collection] Merging all sources → allurls.txt"
cat "$OUTDIR/gau.txt" "$OUTDIR/katana.txt" 2>/dev/null \
    | grep -E "^https?://" \
    | sort -u \
    > "$OUTDIR/allurls.txt"

TOTAL=$(wc -l < "$OUTDIR/allurls.txt" 2>/dev/null || echo 0)
echo "[url-collection] allurls.txt: $TOTAL unique URLs"
echo "[url-collection] Done."
