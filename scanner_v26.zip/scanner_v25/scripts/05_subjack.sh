#!/bin/bash
# Stage 05: Subdomain Takeover
# Tools:  subjack
# Input:  subdomains.txt
# Output: takeover.txt

TARGET=$1
OUTDIR=$2

echo "[subjack] Checking for subdomain takeover vulnerabilities..."
touch "$OUTDIR/takeover.txt"

if [ ! -s "$OUTDIR/subdomains.txt" ]; then
    echo "[subjack] subdomains.txt empty — skipping."
    exit 0
fi

SUBJACK_BIN=""
for candidate in \
    "$HOME/go/bin/subjack" \
    "/usr/local/bin/subjack" \
    "/usr/bin/subjack" \
    "$(which subjack 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then SUBJACK_BIN="$candidate"; break; fi
done

if [ -z "$SUBJACK_BIN" ]; then
    echo "[subjack] ERROR: subjack not found."
    echo "[subjack] Install: go install github.com/haccer/subjack@latest"
    exit 0
fi

echo "[subjack] Using binary: $SUBJACK_BIN"
"$SUBJACK_BIN" -w "$OUTDIR/subdomains.txt" -o "$OUTDIR/takeover.txt" -ssl 2>&1

touch "$OUTDIR/takeover.txt"
COUNT=$(wc -l < "$OUTDIR/takeover.txt" 2>/dev/null || echo 0)
echo "[subjack] Saved: $OUTDIR/takeover.txt ($COUNT results)"
echo "[subjack] Done."
