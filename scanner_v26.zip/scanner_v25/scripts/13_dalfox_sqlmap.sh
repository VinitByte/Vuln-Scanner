#!/bin/bash
# Stage 13: Dalfox (XSS) + SQLMap (SQLi)
# Input:  gf_xss.txt  → dalfox  (fallback: live_paramurls.txt)
#         gf_sqli.txt → sqlmap  (fallback: live_paramurls.txt)
# Output: dalfox.txt, sqlmap.txt

TARGET=$1
OUTDIR=$2

touch "$OUTDIR/dalfox.txt" "$OUTDIR/sqlmap.txt"

# Pick first non-empty file
pick_input() {
    [ -s "$1" ] && echo "$1" || { [ -s "$2" ] && echo "$2" || echo ""; }
}

XSS_INPUT=$(pick_input  "$OUTDIR/gf_xss.txt"  "$OUTDIR/live_paramurls.txt")
SQLI_INPUT=$(pick_input "$OUTDIR/gf_sqli.txt" "$OUTDIR/live_paramurls.txt")

# ── DALFOX ────────────────────────────────────────────────────────────────────
DALFOX_BIN=""
for c in "$HOME/go/bin/dalfox" "/root/go/bin/dalfox" "/usr/local/bin/dalfox" "$(which dalfox 2>/dev/null)"; do
    [ -x "$c" ] 2>/dev/null && DALFOX_BIN="$c" && break
done

if [ -z "$DALFOX_BIN" ]; then
    echo "[dalfox] ERROR: not found. Install: go install github.com/hahwul/dalfox/v2@latest"
elif [ -z "$XSS_INPUT" ]; then
    echo "[dalfox] No input URLs — skipping."
else
    echo "[dalfox] Scanning URLs from $(basename "$XSS_INPUT")..."
    echo ""

    timeout 900 "$DALFOX_BIN" file "$XSS_INPUT" 2>&1 | tee "$OUTDIR/dalfox.txt"
    EXIT_CODE=$?
    [ $EXIT_CODE -eq 124 ] && echo "[dalfox] Timeout after 15 minutes." | tee -a "$OUTDIR/dalfox.txt"

    echo ""
    echo "[dalfox] Done. Saved: $OUTDIR/dalfox.txt ($(wc -l < "$OUTDIR/dalfox.txt") lines)"
fi

echo ""

# ── SQLMAP ────────────────────────────────────────────────────────────────────
if [ -z "$SQLI_INPUT" ]; then
    echo "[sqlmap] No input URLs — skipping."
else
    echo "[sqlmap] Scanning URLs from $(basename "$SQLI_INPUT")..."
    echo ""

    timeout 900 sqlmap -m "$SQLI_INPUT" --batch 2>&1 | tee "$OUTDIR/sqlmap.txt"
    EXIT_CODE=$?
    [ $EXIT_CODE -eq 124 ] && echo "[sqlmap] Timeout after 15 minutes." | tee -a "$OUTDIR/sqlmap.txt"

    echo ""
    echo "[sqlmap] Done. Saved: $OUTDIR/sqlmap.txt ($(wc -l < "$OUTDIR/sqlmap.txt") lines)"
fi
