#!/bin/bash
# Stage 07: URL Filtering
# Tools:  uro, unfurl
# Input:  allurls.txt
# Output: filtered_urls.txt
#         paths.txt        (unfurl paths — unique path segments)
#         params_keys.txt  (unfurl keys  — unique parameter keys)
#
# NOTE: urls_with_params.txt and urls_without_params.txt are built
#       in stage 11 (paramurls) right before ffuf, after paramspider/arjun run.

TARGET=$1
OUTDIR=$2

echo "[url-filter] Starting URL filtering (uro + unfurl)..."

touch "$OUTDIR/filtered_urls.txt" "$OUTDIR/paths.txt" "$OUTDIR/params_keys.txt"

if [ ! -s "$OUTDIR/allurls.txt" ]; then
    echo "[url-filter] allurls.txt empty — skipping."
    exit 0
fi

# ── URO → filtered_urls.txt ───────────────────────────────────────────────────
URO_BIN=""
for candidate in \
    "$HOME/.local/bin/uro" \
    "$(which uro 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then URO_BIN="$candidate"; break; fi
done

if [ -z "$URO_BIN" ]; then
    echo "[uro] ERROR: uro not found. Install: pip install uro"
    echo "[uro] Falling back to raw allurls.txt"
    cp "$OUTDIR/allurls.txt" "$OUTDIR/filtered_urls.txt"
else
    echo "[uro] Deduplicating and filtering URLs..."
    "$URO_BIN" < "$OUTDIR/allurls.txt" > "$OUTDIR/filtered_urls.txt" 2>&1
    echo "[uro] Saved: $OUTDIR/filtered_urls.txt ($(wc -l < "$OUTDIR/filtered_urls.txt") URLs)"
fi

# ── UNFURL → paths.txt + params_keys.txt ─────────────────────────────────────
UNFURL_BIN=""
for candidate in \
    "$HOME/go/bin/unfurl" \
    "/usr/local/bin/unfurl" \
    "/usr/bin/unfurl" \
    "$(which unfurl 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then UNFURL_BIN="$candidate"; break; fi
done

if [ -z "$UNFURL_BIN" ]; then
    echo "[unfurl] ERROR: unfurl not found. Install: go install github.com/tomnomnom/unfurl@latest"
else
    echo "[unfurl] Extracting unique paths from filtered_urls.txt..."
    cat "$OUTDIR/filtered_urls.txt" | "$UNFURL_BIN" format %p 2>/dev/null | grep -v '^$' | sort -u > "$OUTDIR/paths.txt"
    echo "[unfurl] Saved: $OUTDIR/paths.txt ($(wc -l < "$OUTDIR/paths.txt") paths)"

    echo "[unfurl] Extracting unique parameter keys from filtered_urls.txt..."
    cat "$OUTDIR/filtered_urls.txt" | "$UNFURL_BIN" keys 2>/dev/null | grep -v '^$' | sort -u > "$OUTDIR/params_keys.txt"
    echo "[unfurl] Saved: $OUTDIR/params_keys.txt ($(wc -l < "$OUTDIR/params_keys.txt") param keys)"
fi

echo "[url-filter] Done."
