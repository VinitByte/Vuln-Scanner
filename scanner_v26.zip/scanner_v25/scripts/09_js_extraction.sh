#!/bin/bash
# Stage 09: JS Extraction + Analysis
# Tools:  katana (-jc mode), linkfinder, secretfinder, gitleaks
# Input:  live.txt, filtered_urls.txt
# Output: jsfiles.txt           (unique JS URLs — katana -jc + filtered_urls combined + deduped)
#         js_endpoints.txt      (linkfinder output)
#         js_secrets.txt        (secretfinder output)
#         gitleaks.txt          (gitleaks output)

TARGET=$1
OUTDIR=$2

echo "[js-extraction] Starting JS extraction and analysis..."

touch "$OUTDIR/jsfiles.txt" "$OUTDIR/js_endpoints.txt" "$OUTDIR/js_secrets.txt" "$OUTDIR/gitleaks.txt"

# ── SOURCE 1: Katana JS-crawl mode (-jc) ─────────────────────────────────────
KATANA_BIN=""
for candidate in \
    "$HOME/go/bin/katana" \
    "/usr/local/bin/katana" \
    "/usr/bin/katana" \
    "$(which katana 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then KATANA_BIN="$candidate"; break; fi
done

KATANA_JC_TMP="/tmp/katana_jc_$$.txt"
touch "$KATANA_JC_TMP"

if [ -n "$KATANA_BIN" ]; then
    echo "[katana-js] Running katana in JS-crawl mode (-jc)..."
    if [ -f "$OUTDIR/live.txt" ] && [ -s "$OUTDIR/live.txt" ]; then
        "$KATANA_BIN" -list "$OUTDIR/live.txt" -jc -o "$KATANA_JC_TMP" 2>&1
    else
        "$KATANA_BIN" -u "https://$TARGET" -jc -o "$KATANA_JC_TMP" 2>&1
    fi
    KATANA_JS_COUNT=$(grep -cE "\.js($|\?)" "$KATANA_JC_TMP" 2>/dev/null || echo 0)
    echo "[katana-js] katana -jc found $KATANA_JS_COUNT JS URLs"
else
    echo "[katana-js] katana not found — skipping JS-crawl mode."
fi

# ── SOURCE 2: Extract .js URLs from filtered_urls.txt ─────────────────────────
echo "[js-extraction] Extracting .js URLs from filtered_urls.txt..."
FILTERED_JS_TMP="/tmp/filtered_js_$$.txt"
touch "$FILTERED_JS_TMP"
if [ -f "$OUTDIR/filtered_urls.txt" ] && [ -s "$OUTDIR/filtered_urls.txt" ]; then
    grep -E "\.js($|\?)" "$OUTDIR/filtered_urls.txt" | sort -u > "$FILTERED_JS_TMP"
    echo "[js-extraction] filtered_urls.txt yielded $(wc -l < "$FILTERED_JS_TMP") JS URLs"
fi

# ── COMBINE + DEDUPLICATE ─────────────────────────────────────────────────────
echo "[js-extraction] Combining and deduplicating JS sources..."
JS_RAW_TMP="/tmp/js_raw_$$.txt"
{
    grep -E "\.js($|\?)" "$KATANA_JC_TMP" 2>/dev/null
    cat "$FILTERED_JS_TMP" 2>/dev/null
} | sort -u > "$JS_RAW_TMP"

RAW_COUNT=$(wc -l < "$JS_RAW_TMP")
echo "[js-extraction] Raw unique JS URLs: $RAW_COUNT"

rm -f "$KATANA_JC_TMP" "$FILTERED_JS_TMP"

# ── LIVE FILTER → jsfiles.txt ─────────────────────────────────────────────────
HTTPX_BIN=""
for candidate in \
    "$HOME/go/bin/httpx" \
    "/usr/local/bin/httpx" \
    "/usr/bin/httpx" \
    "$(which httpx 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then HTTPX_BIN="$candidate"; break; fi
done

if [ -n "$HTTPX_BIN" ] && [ -s "$JS_RAW_TMP" ]; then
    echo "[js-extraction] Live filtering JS URLs with httpx..."
    "$HTTPX_BIN" -l "$JS_RAW_TMP" -silent -mc 200 2>/dev/null > "$OUTDIR/jsfiles.txt"
    echo "[js-extraction] Live JS files: $(wc -l < "$OUTDIR/jsfiles.txt") / $RAW_COUNT"
else
    [ -z "$HTTPX_BIN" ] && echo "[js-extraction] httpx not found — skipping live filter, keeping all JS URLs"
    cp "$JS_RAW_TMP" "$OUTDIR/jsfiles.txt"
fi

rm -f "$JS_RAW_TMP"

JS_COUNT=$(wc -l < "$OUTDIR/jsfiles.txt")
echo "[js-extraction] Total live JS files: $JS_COUNT → $OUTDIR/jsfiles.txt"

if [ "$JS_COUNT" -eq 0 ]; then
    echo "[js-extraction] No JS files found — skipping analysis."
    exit 0
fi

# ── LINKFINDER → js_endpoints.txt ────────────────────────────────────────────
LINKFINDER_BIN=""
for candidate in \
    "$HOME/tools/LinkFinder/linkfinder.py" \
    "$HOME/LinkFinder/linkfinder.py" \
    "$(which linkfinder.py 2>/dev/null)"
do
    if [ -f "$candidate" ]; then LINKFINDER_BIN="$candidate"; break; fi
done

if [ -z "$LINKFINDER_BIN" ]; then
    echo "[linkfinder] ERROR: LinkFinder not found."
    echo "[linkfinder] Install: git clone https://github.com/GerbenJavado/LinkFinder ~/tools/LinkFinder"
else
    echo "[linkfinder] Extracting endpoints from JS files (10 min max)..."
    while IFS= read -r jsurl; do
        [ -z "$jsurl" ] && continue
        timeout 10m python3 "$LINKFINDER_BIN" -i "$jsurl" -o cli 2>/dev/null >> "$OUTDIR/js_endpoints.txt" || true
    done < "$OUTDIR/jsfiles.txt"
    sort -u "$OUTDIR/js_endpoints.txt" -o "$OUTDIR/js_endpoints.txt"
    echo "[linkfinder] Saved: $OUTDIR/js_endpoints.txt ($(wc -l < "$OUTDIR/js_endpoints.txt") endpoints)"
fi

# ── SECRETFINDER → js_secrets.txt ────────────────────────────────────────────
SECRETFINDER_BIN=""
for candidate in \
    "$HOME/tools/SecretFinder/SecretFinder.py" \
    "$HOME/SecretFinder/SecretFinder.py" \
    "$(which SecretFinder.py 2>/dev/null)"
do
    if [ -f "$candidate" ]; then SECRETFINDER_BIN="$candidate"; break; fi
done

if [ -z "$SECRETFINDER_BIN" ]; then
    echo "[secretfinder] ERROR: SecretFinder not found."
    echo "[secretfinder] Install: git clone https://github.com/m4ll0k/SecretFinder ~/tools/SecretFinder"
else
    echo "[secretfinder] Scanning JS files for secrets..."
    while IFS= read -r jsurl; do
        [ -z "$jsurl" ] && continue
        python3 "$SECRETFINDER_BIN" -i "$jsurl" -o cli 2>/dev/null >> "$OUTDIR/js_secrets.txt"
    done < "$OUTDIR/jsfiles.txt"
    sort -u "$OUTDIR/js_secrets.txt" -o "$OUTDIR/js_secrets.txt"
    echo "[secretfinder] Saved: $OUTDIR/js_secrets.txt ($(wc -l < "$OUTDIR/js_secrets.txt") secrets)"
fi

# ── GITLEAKS — download each JS file, scan, then remove temp ─────────────────
GITLEAKS_BIN=""
for candidate in \
    "$HOME/go/bin/gitleaks" \
    "$HOME/.local/bin/gitleaks" \
    "/usr/local/bin/gitleaks" \
    "/usr/bin/gitleaks" \
    "$(which gitleaks 2>/dev/null)"
do
    if [ -x "$candidate" ] 2>/dev/null; then GITLEAKS_BIN="$candidate"; break; fi
done

if [ -z "$GITLEAKS_BIN" ]; then
    echo "[gitleaks] ERROR: gitleaks not found."
    echo "[gitleaks] Install: go install github.com/gitleaks/gitleaks/v8@latest"
else
    echo "[gitleaks] Scanning each JS file for secrets (per-file mode)..."
    GITLEAKS_TMP_DIR="/tmp/gitleaks_js_$$"
    mkdir -p "$GITLEAKS_TMP_DIR"

    while IFS= read -r jsurl; do
        [ -z "$jsurl" ] && continue
        echo "[+] $jsurl" >> "$OUTDIR/gitleaks.txt"
        TEMP_JS="$GITLEAKS_TMP_DIR/temp.js"
        curl -s --max-time 10 "$jsurl" > "$TEMP_JS" 2>/dev/null
        if [ -s "$TEMP_JS" ]; then
            "$GITLEAKS_BIN" detect \
                --source "$GITLEAKS_TMP_DIR" \
                --no-git \
                --report-format text \
                2>/dev/null >> "$OUTDIR/gitleaks.txt" || true
        fi
        rm -f "$TEMP_JS"
    done < "$OUTDIR/jsfiles.txt"

    rm -rf "$GITLEAKS_TMP_DIR"
    echo "[gitleaks] Saved: $OUTDIR/gitleaks.txt"
fi

echo "[js-extraction] Done."

