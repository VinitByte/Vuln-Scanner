#!/bin/bash
# Stage 10: Parameter Discovery
# Tools:  paramspider (~/venv/bin/), arjun (~/venv/bin/)
# Input:  live.txt, params_keys.txt (unfurl keys, from stage 07)
# Output: paramspider.txt      — paramspider URLs (FUZZ stripped → real param=1)
#         arjun_params.txt     — flat list of param names discovered by arjun
#         total_params.txt     — merged unique param names (arjun + unfurl keys)
#                                used as fuzzing wordlist supplement in stage 11

TARGET=$1
OUTDIR=$2

echo "[param-discovery] Starting parameter discovery..."

DOMAIN=$(echo "$TARGET" | sed 's|^https\?://||' | cut -d'/' -f1)

touch "$OUTDIR/paramspider.txt" \
      "$OUTDIR/arjun_params.txt" \
      "$OUTDIR/total_params.txt"

# ── PARAMSPIDER (venv) → paramspider.txt ──────────────────────────────────────
PARAMSPIDER_BIN="$HOME/venv/bin/paramspider"
if [ ! -x "$PARAMSPIDER_BIN" ]; then
    echo "[paramspider] ERROR: not found at $PARAMSPIDER_BIN"
    echo "[paramspider] Install: ~/venv/bin/pip install paramspider"
else
    echo "[paramspider] Running for: $DOMAIN"
    "$PARAMSPIDER_BIN" -d "$DOMAIN" 2>&1

    # Find raw output, strip FUZZ placeholders → real URLs
    OUTPUT_FOUND=0
    for CANDIDATE in \
        "results/${DOMAIN}.txt" \
        "output/${DOMAIN}.txt" \
        "${DOMAIN}.txt"
    do
        if [ -f "$CANDIDATE" ] && [ -s "$CANDIDATE" ]; then
            sed 's/=FUZZ/=1/g' "$CANDIDATE" \
                | grep "^http" | grep "=" | sort -u \
                > "$OUTDIR/paramspider.txt"
            echo "[paramspider] Output copied from $CANDIDATE"
            OUTPUT_FOUND=1
            break
        fi
    done

    if [ "$OUTPUT_FOUND" -eq 0 ] && ls results/*.txt 1>/dev/null 2>&1; then
        cat results/*.txt | sed 's/=FUZZ/=1/g' \
            | grep "^http" | grep "=" | sort -u \
            > "$OUTDIR/paramspider.txt"
        OUTPUT_FOUND=1
    fi

    [ "$OUTPUT_FOUND" -eq 0 ] && echo "[paramspider] WARNING: No output found."
    echo "[paramspider] Saved: $OUTDIR/paramspider.txt ($(wc -l < "$OUTDIR/paramspider.txt") URLs)"
fi

# ── ARJUN (venv) → arjun_params.txt ──────────────────────────────────────────
# Run on live hosts, extract param NAMES only (not full URLs)
ARJUN_BIN="$HOME/venv/bin/arjun"
if [ ! -x "$ARJUN_BIN" ]; then
    echo "[arjun] ERROR: not found at $ARJUN_BIN"
    echo "[arjun] Install: ~/venv/bin/pip install arjun"
else
    echo "[arjun] Discovering parameters on live hosts (up to 20)..."
    ARJUN_TMP="/tmp/arjun_params_$$.txt"
    > "$ARJUN_TMP"

    ARJUN_INPUT="$OUTDIR/live.txt"
    [ ! -s "$ARJUN_INPUT" ] && ARJUN_INPUT=""

    if [ -n "$ARJUN_INPUT" ]; then
        while IFS= read -r url; do
            [ -z "$url" ] && continue
            echo "[arjun] Scanning: $url"
            ARJUN_OUT="/tmp/arjun_out_$$.json"
            "$ARJUN_BIN" -u "$url" -oJ "$ARJUN_OUT" 2>&1 || true
            if [ -f "$ARJUN_OUT" ]; then
                python3 - "$ARJUN_OUT" >> "$ARJUN_TMP" 2>/dev/null << 'PYEOF'
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    for u, params in d.items():
        for p in params:
            print(p)
except:
    pass
PYEOF
                rm -f "$ARJUN_OUT"
            fi
        done < <(head -20 "$ARJUN_INPUT")
    else
        ARJUN_OUT="/tmp/arjun_out_$$.json"
        echo "[arjun] Scanning: https://$TARGET"
        "$ARJUN_BIN" -u "https://$TARGET" -oJ "$ARJUN_OUT" 2>&1 || true
        if [ -f "$ARJUN_OUT" ]; then
            python3 - "$ARJUN_OUT" >> "$ARJUN_TMP" 2>/dev/null << 'PYEOF'
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    for u, params in d.items():
        for p in params:
            print(p)
except:
    pass
PYEOF
            rm -f "$ARJUN_OUT"
        fi
    fi

    sort -u "$ARJUN_TMP" > "$OUTDIR/arjun_params.txt"
    rm -f "$ARJUN_TMP"
    echo "[arjun] Saved: $OUTDIR/arjun_params.txt ($(wc -l < "$OUTDIR/arjun_params.txt") param names)"
fi

# ── BUILD total_params.txt ─────────────────────────────────────────────────────
# arjun_params.txt  (discovered param names)
# params_keys.txt   (unfurl keys from stage 07, already unique)
echo "[param-discovery] Building total_params.txt..."

UNFURL_KEYS_COUNT=$(wc -l < "$OUTDIR/params_keys.txt" 2>/dev/null || echo 0)
ARJUN_COUNT=$(wc -l < "$OUTDIR/arjun_params.txt" 2>/dev/null || echo 0)

{
    cat "$OUTDIR/arjun_params.txt"  2>/dev/null
    cat "$OUTDIR/params_keys.txt"   2>/dev/null
} | grep -v "^[[:space:]]*$" | sort -u > "$OUTDIR/total_params.txt"

echo "[param-discovery] total_params.txt: $(wc -l < "$OUTDIR/total_params.txt") unique param names"
echo "[param-discovery] (arjun: $ARJUN_COUNT  +  unfurl keys: $UNFURL_KEYS_COUNT)"
echo "[param-discovery] Done."
