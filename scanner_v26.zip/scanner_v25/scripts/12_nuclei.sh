#!/bin/bash
# Stage 12: Nuclei Template Scanning
# Input:  target URL
# Output: nuclei.txt

TARGET=$1
OUTDIR=$2

if echo "$TARGET" | grep -qE '^https?://'; then
    FULL_URL="$TARGET"
else
    FULL_URL="https://$TARGET"
fi

echo "[nuclei] Scanning: $FULL_URL"

NUCLEI_BIN=""
for candidate in "$HOME/go/bin/nuclei" "/root/go/bin/nuclei" "/usr/local/bin/nuclei" "/usr/bin/nuclei" "$(which nuclei 2>/dev/null)"; do
    [ -x "$candidate" ] 2>/dev/null && NUCLEI_BIN="$candidate" && break
done

if [ -z "$NUCLEI_BIN" ]; then
    echo "[nuclei] ERROR: nuclei not found. Install: go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    exit 0
fi

# Run nuclei:
# - terminal pe color output (normal terminal experience)
# - file me clean output (no ANSI codes) via -no-color flag on file output
TMPFILE="/tmp/nuclei_raw_$$.txt"

"$NUCLEI_BIN" -u "$FULL_URL" -no-color 2>&1 | tee "$TMPFILE"

# Strip any remaining ANSI codes before saving to file
sed 's/\x1b\[[0-9;]*m//g' "$TMPFILE" > "$OUTDIR/nuclei.txt"
rm -f "$TMPFILE"

echo ""
echo "[nuclei] Done. Saved: $OUTDIR/nuclei.txt ($(wc -l < "$OUTDIR/nuclei.txt") lines)"
