#!/bin/bash
# Stage 14: Nikto — Server Audit
# Input:  target URL
# Output: nikto.txt

TARGET=$1
OUTDIR=$2

if echo "$TARGET" | grep -qE '^https?://'; then
    FULL_URL="$TARGET"
else
    FULL_URL="https://$TARGET"
fi

touch "$OUTDIR/nikto.txt"

echo "[nikto] Scanning: $FULL_URL"

NIKTO_BIN=""
for candidate in "$(which nikto 2>/dev/null)" "/usr/bin/nikto" "/usr/local/bin/nikto"; do
    [ -x "$candidate" ] 2>/dev/null && NIKTO_BIN="$candidate" && break
done

if [ -z "$NIKTO_BIN" ]; then
    echo "[nikto] ERROR: nikto not found. Install: apt install nikto"
else
    "$NIKTO_BIN" -h "$FULL_URL" -c all 2>&1 | tee "$OUTDIR/nikto.txt"
    echo "[nikto] Done. Saved: $OUTDIR/nikto.txt ($(wc -l < "$OUTDIR/nikto.txt") lines)"
fi
